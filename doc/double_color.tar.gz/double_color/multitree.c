/*******************************************
*coder: a, time
*******************************************/

#define MAXCHILD 5

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

typedef struct _TREENODE
{
    int weight;   /*store weight of each child*/
    int cnChild;    /*record number of child*/
    struct _TREENODE *parent;
    struct _TREENODE *child[MAXCHILD];
} TREENODE, *PTREENODE;

void *node_mallocz(unsigned int size)
{
    void *ptr = NULL;

    ptr = malloc(size);
    if(ptr)
        memset(ptr, 0, size);

    return ptr;
}

/*insert a new child for ppNode, 
*weight of the new child is wieght 
*/
PTREENODE InsertNode(PTREENODE *parent,int weight)
{
    int cnChild;
    PTREENODE child = NULL;
    
    cnChild = (*parent)->cnChild;
    if(cnChild >= MAXCHILD)
    {
        printf("failed one parent at most have %d child\n", MAXCHILD);
        return child;
    }
    child = (PTREENODE)node_mallocz(sizeof(TREENODE));
    if(!child)
    {
        printf("failed when alloc memory for child\n");
        return child;
    }
    
    child->weight = weight;
    child->cnChild =0;
    child->parent = *parent;
    
    (*parent)->child[cnChild] = child;
    (*parent)->cnChild++;
    
    return child;
}

void PrintTree(PTREENODE root)
{
    static int depth = 0;
    int i;
    if (root == NULL)
    {
        return;
    }
    
    for (i=0; i<depth; i++)
    {
        printf(" ");
    }
    
    printf("%d\n",root->weight);
    for (i=0; i<root->cnChild; i++)
    {
        depth++;
        PrintTree((root->child)[i]);
        depth--;
    }
}

void PrintTreelast(PTREENODE root)
{
    static int depth = 0;
    int i;
    
    if (root == NULL)
    {
        return;
    }
    
    for (i=0;i<root->cnChild;i++)
    {
        depth++;
        PrintTreelast((root->child)[i]);
        depth--;
    }
    
    for (i=0;i<depth;i++)
    {
        printf(" ");
    }
    printf("%d\n",root->weight);
}

void destroyTree(PTREENODE root)
{
    int i;
    
    if (root == NULL)
    {
        return;
    }
    
    for (i=0;i<root->cnChild;i++)
    {
        destroyTree((root->child)[i]);
    }
    
    free(root);
}

int main()
{
    PTREENODE root;
    PTREENODE temp1,temp2;

    /*root node*/
    root = (PTREENODE)node_mallocz(sizeof(TREENODE));
    root->weight = 1;
    root->cnChild =0;
    root->parent = NULL;

    /*insert 11 and 12 as child of root*/
    temp1 = InsertNode(&root,11);
    temp2 = InsertNode(&root,12);

    InsertNode(&temp1,111);
    InsertNode(&temp1,112);
    InsertNode(&temp1,113);
    
    InsertNode(&temp2,121);
    InsertNode(&temp2,122);
    InsertNode(&temp2,123);
    
    PrintTree(root);
    printf("\n*****************\n");
    PrintTreelast(root);
    destroyTree(root);
    
    return 0;
}
