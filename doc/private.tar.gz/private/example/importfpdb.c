#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "my_global.h"
#include "m_string.h"
#include "mysql.h"
#define INCLUDE_MYSQL_LIST_DEFINE

#define MAX_FP_INDEX_LEN        128
#define FP_SCHEDULE_FILE        "./fp_schedule.txt"
#define FP_SCHEDULE_IDENTIFIER  "#yuvad fp schedule"
#define SQL_STR_LENGTH  3000

typedef struct Tgalist{
	struct Tgalist *next;
	char *filename;
	int delayframenum;
    
    /*for fp overlay*/
    char id[MAX_FP_INDEX_LEN];
    char name[MAX_FP_INDEX_LEN];
    char description[MAX_FP_INDEX_LEN];
    char channel[MAX_FP_INDEX_LEN];

    char file_fpm[256];
    char file_fpd[256];
}Tgalist;

Tgalist fp_head;
Tgalist matchedfp_head;

static int display_list(Tgalist *head)
{
	Tgalist *ptr;
    int num = 0;

	if(head->next == NULL) {
        printf("list in NULL\n");
		return 0;
	}

	ptr = head->next;
	while(ptr != NULL) {
        printf("id: %s\n", ptr->id);

        ptr = ptr->next;
        num++;
    }
    printf("num: %d\n", num);

    return 0;
}

/*
*return 0: never repeat;
*       1: repeat
*/
static int search_same_fp(Tgalist *head, char *id)
{
	Tgalist *ptr;

	if(head->next == NULL) {
		return 0;
	}

	ptr = head->next;
	while(ptr != NULL) {
        if(!strcmp(ptr->id, id))
            return 1;

        ptr = ptr->next;
    }

    return 0;
}

void inserttgalist(Tgalist *head, Tgalist *new)
{
	Tgalist *ptr;
	Tgalist *pre;

	if(head->next == NULL) {
		head->next = new;
		return;
	}

	pre = head;
	ptr = head->next;
	while(ptr != NULL) {
		if(strcmp(ptr->filename, new->filename) > 0) {/*ptr > new*/
			new->next = ptr;
			pre->next = new;
			return;
		}
		
		pre = ptr;
		ptr = ptr->next;
	}
	
	pre->next = new;

	return;
}

void freetgalist(Tgalist *head)
{
	Tgalist *ptr;
	Tgalist *pre;

	ptr = head->next;

	while(ptr != NULL) {
		pre = ptr;
		ptr = ptr->next;

		if(pre->filename)
            free(pre->filename);
		
        free(pre);
	}

	head->next = NULL;
}

static int db_open( MYSQL **conn )
{
    int i = 0;
    
    /* connect to mysql for get data from database*/
    *conn = mysql_init(NULL);
    while(mysql_real_connect(*conn, "127.0.0.1", "root", "yuvadbj", "overlay", 0, NULL,
                            CLIENT_INTERACTIVE) == NULL) {
        printf("can not open mysql: %d\n", i);
        if(++i == 3)
            return -1;
        sleep(3);
    }
    
    mysql_query(*conn, "SET NAMES 'utf8'");/* use utf8 as character set */
    
    return 0;
}

static int db_close( MYSQL **conn )
{
    mysql_close(*conn);
    return 0;
}

/* delete all item of OL_FP_Database */
int delete_fp_from_db()
{
    MYSQL *conn;
    char sql_str[SQL_STR_LENGTH];
    
    db_open(&conn);
    
    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
            "DELETE FROM OL_FP_Database ");
    
    //printf("sql_str: %s\n",sql_str);
    if(mysql_query(conn, sql_str) != 0) {
        printf("delete fp failed: %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    
    db_close(&conn);
    return 0;
}

int insert_into_db(Tgalist *postentry)
{
    char sql_str[SQL_STR_LENGTH];
    char tmp_str[SQL_STR_LENGTH];
    char tmp_cpy[SQL_STR_LENGTH];
    MYSQL *conn;
    char *tmppos;
    
    db_open(&conn);

    memset(tmp_str, 0, SQL_STR_LENGTH);
    memset(tmp_cpy, 0, SQL_STR_LENGTH);
    memset(sql_str, 0, SQL_STR_LENGTH);
    
    snprintf(tmp_str, sizeof(sql_str),
            "INSERT INTO OL_FP_Database ( "
            "FP_ID, FP_NAME ) "
            "VALUES ( ");
            
    strncpy(tmp_cpy,tmp_str,strlen(tmp_str));
    tmppos = strmov(sql_str, tmp_cpy);
    //dbg_msg("sql_str: %s\n",sql_str);
    
    /*insert fp id*/
    if(postentry->id == NULL) {
        *tmppos++ = '\'';
        *tmppos++ = '0';
        *tmppos++ = '\'';
        *tmppos++ = ',';
    }
    else {
        *tmppos++ = '\'';
        tmppos += mysql_real_escape_string(conn,tmppos,postentry->id, strlen(postentry->id));
        *tmppos++ = '\'';
        *tmppos++ = ',';
    }
    
    #if 0
    /*insert fp name*/
    if(postentry->name == NULL) {
        *tmppos++ = '\'';
        *tmppos++ = '0';
        *tmppos++ = '\'';
        *tmppos++ = ')';
    }
    else {
        *tmppos++ = '\'';
        tmppos += mysql_real_escape_string(conn, tmppos, postentry->name, strlen(postentry->name));
        *tmppos++ = '\'';
        *tmppos++ = ')';
    }
    #else
    /*insert fp describe*/
    if(postentry->description == NULL) {
        *tmppos++ = '\'';
        *tmppos++ = '0';
        *tmppos++ = '\'';
        *tmppos++ = ')';
    }
    else {
        *tmppos++ = '\'';
        tmppos += mysql_real_escape_string(conn, tmppos, postentry->description, strlen(postentry->description));
        *tmppos++ = '\'';
        *tmppos++ = ')';
    }
    #endif
    
    //printf("sql_str: %s\n",sql_str);
    if(mysql_query(conn, sql_str) != 0) {
        printf("insert log failed: %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }

    db_close(&conn);
    return 0;
}

void write_fp_to_db(Tgalist *head)
{
	Tgalist *ptr;
    char str_cmd[256];

    //delete_fp_from_db();

    ptr = head->next;
    while( ptr != NULL) {
        //if(strlen(ptr->name))
        if(strlen(ptr->description) && search_same_fp(&matchedfp_head, ptr->id)) {
            //insert_into_db(ptr);
            printf("file fpm: %s\n", ptr->file_fpm);
            printf("file fpd: %s\n", ptr->file_fpd);
            
            memset(str_cmd, 0, sizeof(str_cmd));
            snprintf(str_cmd, sizeof(str_cmd), " mv /home/yxliu/tmp/fp_db/%s /home/yxliu/tmp/demo ", ptr->file_fpm);
            system(str_cmd);
            memset(str_cmd, 0, sizeof(str_cmd));
            snprintf(str_cmd, sizeof(str_cmd), " mv /home/yxliu/tmp/fp_db/%s /home/yxliu/tmp/demo ", ptr->file_fpd);
            system(str_cmd);
        }
        
        ptr = ptr->next;
	}

    return;
}

void writescheduledb(Tgalist *head)
{
    FILE *fd;
	Tgalist *ptr;
	
    fd = fopen( FP_SCHEDULE_FILE, "w");
    if(!fd)
    {
        printf("open %s failed\n", FP_SCHEDULE_FILE);
        return;
    }

    fprintf(fd, "%s\n", FP_SCHEDULE_IDENTIFIER);
    ptr = head->next;
    while( ptr != NULL) {
        //printf("id: %s\n", ptr->id);
        //printf("description: %s\n", ptr->description);
        //printf("name: %s\n", ptr->name);
        
        //fprintf(fd, "\"%s\" \"%s\" \"%s\" \"%s\"\n", ptr->id, ptr->description, "down", "there is no content");
        fprintf(fd, "\"%s\" \"%s\" \"%s\" \"%s yuvad 字幕叠加\"\n", ptr->id, ptr->name, "down", ptr->name);
        ptr = ptr->next;
	}

    fclose(fd);
    return;
}

int analysefpdb(char *strcmd, char *buf)
{
    FILE *fd;
    char *offset;
    
    fd = popen( strcmd, "r");
    if(!fd)
    {
        fprintf(stdout, "popen %s failed\n", strcmd);
        return -1;
    }
    if (!fgets(buf, MAX_FP_INDEX_LEN, fd)) 
    {
        fprintf(stdout, "can not get result by %s\n", strcmd);
        return -1;
    }
    
    offset = index(buf, '\n');
    if(offset)
        *offset = 0;

    pclose(fd);
    
    return 0;
}

#define MAX_LEN_EACH_LINE   500
static int craete_matched_fp_list(Tgalist *head, char *matchedfp)
{
    FILE *fd;
    char str[MAX_LEN_EACH_LINE];
    char *retptr;
    char *offset;

	Tgalist *ptr;
    int insertmatchednum = 0;
    int allmatchednum = 0;
    
    fd = fopen(matchedfp ,"r");
    if(fd == NULL) 
    {
        printf("fopen (%s) is failed \n", matchedfp);
        return -1;
    }
    
    while(1)
    {
        memset(str, 0, MAX_LEN_EACH_LINE);
        retptr = fgets(str, MAX_LEN_EACH_LINE, fd);
        if(!retptr)
            break;

        offset = index(str, '\n');
        if(offset)
            *offset = 0;
        //printf("%s\n", str);

        if(*str == '#') /*skip note line*/
            continue;
		
        ptr = (Tgalist *)malloc(sizeof(Tgalist));
		ptr->filename = strdup(matchedfp);
		strcpy(ptr->id,str);
		ptr->next = NULL;
        //printf("index: %s, str: %s\n",ptr->id, str);
        
        if(!search_same_fp(head, ptr->id))
        {
            inserttgalist(head, ptr);
            insertmatchednum++; 
        }
        allmatchednum++;
    }
    //printf("allmatched num: %d, insert num: %d\n", allmatchednum, insertmatchednum);
    fclose(fd);

    display_list(head);

    return 0;
}

static int create_fp_list_according_to_fpdb(Tgalist *head, char *path)
{
	DIR *dir;
	struct dirent *dirptr;
	Tgalist *ptr;
    int countnum;
    char str[1024];
    char *p;
	
    dir =opendir(path);
	if(dir == NULL)
		return 0;

    countnum = 0; 
	while((dirptr = readdir(dir))!=NULL) {
		//if( !strncasecmp(dirptr->d_name, ".", 1) || !strncasecmp(dirptr->d_name, "..", 2) )
		if( !strcmp(dirptr->d_name, ".") || !strcmp(dirptr->d_name, "..") || !strstr(dirptr->d_name, ".fpm") )
            continue;
       

        //fprintf(stdout, "d_name: %s\n",dirptr->d_name);
		ptr = (Tgalist *)malloc(sizeof(Tgalist));
		ptr->delayframenum = 25;
		ptr->filename = strdup(dirptr->d_name);
		ptr->next = NULL;
        
        strcpy(ptr->file_fpm, dirptr->d_name);
        strcpy(ptr->file_fpd, dirptr->d_name);
        p = strstr(ptr->file_fpd, ".fpm");
        //printf("%s\n", p);
        *(p+3) = 'd';
        //printf("%s\n", p);
        
        
        /* get id */
        memset(str, 0, 1024);
        snprintf(str, sizeof(str), " cat %s/%s | grep \"^id: \" | sed \"s/id: //\" ", path, dirptr->d_name);
        analysefpdb(str, ptr->id);
        
        /* get name */
        memset(str, 0, 1024);
        snprintf(str, sizeof(str), " cat %s/%s | grep \"^name: \" | sed \"s/name: //\" ", path, dirptr->d_name);
        analysefpdb(str, ptr->name);
        
        /* get description */
        memset(str, 0, 1024);
        snprintf(str, sizeof(str), " cat %s/%s | grep \"^description: \" | sed \"s/description: //\" ", path, dirptr->d_name);
        analysefpdb(str, ptr->description);

		inserttgalist(head, ptr);

        countnum++;
	}
	closedir(dir);
    printf("countnum: %d\n", countnum);
    return 0;
}

void usage()
{
	fprintf(stdout,"./importfpdb path matched_fp \n");
	fprintf(stdout,"example ./importfpdb /mnt/adspace/fp /mnt/adspace/matched_fp.txt \n");
}

int main(int argc, char *argv[])
{
	char *path;
    char *matchedfp;

	if(argc != 3){
		usage();
		return 0;
	}
	
	fp_head.next = NULL;
	path = strdup(argv[1]);
	fprintf(stdout,"path: %s\n", path);
    create_fp_list_according_to_fpdb(&fp_head, path);
	
	matchedfp_head.next = NULL;
    matchedfp = strdup(argv[2]);
	fprintf(stdout,"matchedfp: %s\n", matchedfp);
    craete_matched_fp_list(&matchedfp_head, matchedfp);

    //writescheduledb(&fp_head);
    write_fp_to_db(&fp_head);

    freetgalist(&fp_head);
    freetgalist(&matchedfp_head);

    return 0;
}
