#ifndef TASK_MGT_H
#define TASK_MGT_H

#include "../include/ot_common.h"
#include "../include/yuvad_list.h"
#include "../debug.h"


#define MAX_REQUEST_NUMBER      100
#define PRIORITY_QUEUE_NUM      3

typedef enum
{
    OUTPUT_LIST,
    INPUT_LIST,
    TASK_LIST
}tm_list_type_t;

typedef struct  
{
    struct list_head node; 
    
    int id;
    
    /* input */
    int32_t input_file_num;
    char **input_files;
    
    /* pointer to the output config in request */
    int32_t output_index;           /*offset of tm_request_node_t.output_list*/
    char output_filename[512];
    
    ot_status_t status;
    int32_t error;
    int32_t progress;
}tm_task_node_t;

typedef struct  
{
    struct list_head node; 
    int32_t id;

    struct list_head input_list;    /*save ot_input_t node*/
    struct list_head output_list;   /*save ot_output_t node*/
    
    struct list_head task_list;      /*head of atomic task*/
    int32_t taksNumber;
    
    ot_status_t status;  
    int32_t progress;
    int32_t priority;
    int32_t error;
}tm_request_node_t;

typedef struct  
{
    struct list_head list; /*head of request queue*/
    pthread_mutex_t lock;

    int requestNumber;
}tm_request_queue_t;


extern void tm_init_task_management();


#endif
