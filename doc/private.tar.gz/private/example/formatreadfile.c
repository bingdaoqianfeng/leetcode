#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "yuvad_list.h"

#define FP_SCHEDULE_FILE  "./fp_schedule.txt"
#define FP_PROFILE_FILE  "./fp_profile.txt"
#define FP_DEBUG_LOG  "./fp_log.txt"
#define MAX_LEN_EACH_LINE 500
#define MAX_INT_LEN 128

#define FP_SCHEDULE_IDENTIFIER  "#yuvad fp schedule"

#define DB_TYPE_SCHEDULE    1
#define DB_TYPE_PROFILE     2

typedef struct fp_profile_t
{
    struct list_head node;
    char *profile_name;
    int start_x;
    int start_y;
    int width;
    int fontsize;
    int fontcolor;
    int shadowsize;
    int shadowcolor;
}fp_profile_t;

typedef struct fp_schedule_t
{
    struct list_head node;
    char *ad_name;
    char *profile_name;
    char *ad_content;
    fp_profile_t *profile;
}fp_schedule_t;

struct list_head fpScheduledb;
struct list_head fpProfiledb;

static fp_profile_t defaultProfile=
{
    .profile_name = "default",
    start_x:10,
    start_y:400,
    width:500,
    fontsize:30,
    fontcolor:16777215,
    shadowsize:4,
    shadowcolor:0
};

char *fp_ol_partingstr(char **src, char *delim, int *strlen)
{
    char *ptr;
    char *pre;
    char *head;
    int len;
    char *stresc = "\\";
    char *escptr;
    char *escpre;
        
    //printf("1 src: %s\n", *src);
    ptr = *src;
    pre = ptr;
    head = NULL;
    len = 0;
    *strlen = 0;

    /*find the first double quotes*/
    while(*ptr)
    {
        if(*ptr == *delim)
            break;
        pre = ptr;
        ptr++;
    }
    if( !*ptr || !*(ptr++) ) /*not find double quotes, or reach the end of the string*/
        return NULL;
    
    /*find the second double quotes*/
    head = ptr; 
    while(*ptr)
    {
        if( (*ptr == *delim) && (*pre == *stresc) )
        {/*find escape character, move string from ptr to pre until end.*/
            escpre = pre;
            escptr = ptr;
            while(*escptr)
            {
                *escpre = *escptr;
                escpre++;
                escptr++;
            }
            *escpre = *escptr;
            continue;
        }
        if( (*ptr == *delim) && (*pre != *stresc) )
            break;
        
        pre = ptr;
        ptr++;
        len++;
    }
    if(!*ptr) /*not find the second double quotes*/
        return NULL;
    
    *strlen = len;
    *src = ptr + 1;
    //printf("2 src: %s, len: %d, head: %s\n", *src, len, head);

    return head;
}

void fp_ol_search_profile(char *profile_name, fp_profile_t **fpProfile)
{
    struct list_head *pos;
    struct list_head *head;
    fp_profile_t *pos_entry = NULL;
    
    head = &fpProfiledb;
    if(list_empty(head)) 
    {
        *fpProfile = &defaultProfile;
        return;
    }

    list_for_each(pos, head) {
        pos_entry = list_entry(pos, fp_profile_t, node);
        if( !strcmp(profile_name, pos_entry->profile_name) )
        {
            *fpProfile = pos_entry;
            return;
        }
    }
    
    *fpProfile = &defaultProfile;

    return;
}

void fp_ol_display_db(struct list_head *head, int type )
{
    struct list_head *pos;
    //char str[MAX_LEN_EACH_LINE];
    
    if(list_empty(head)) 
        return;
    
    switch(type)
    {
        case DB_TYPE_SCHEDULE: /*schedlue*/
        {
            fp_schedule_t *pos_entry = NULL;
            
            printf("\n---schedule db---\n");
            list_for_each(pos, head) {
                pos_entry = list_entry(pos, fp_schedule_t, node);
                printf("ad_name: %s, profile_name: %s, ad_content: %s\n", 
                    pos_entry->ad_name, pos_entry->profile_name, pos_entry->ad_content);
                /*if(pos_entry->profile)
                    printf("profile_name: %s, start_x: %d, start_y: %d, width: %d, "
                            "fontsize: %d, fontcolor: %d, shadowsize: %d, shadowcolor: %d\n", 
                            pos_entry->profile->profile_name, pos_entry->profile->start_x, 
                            pos_entry->profile->start_y, pos_entry->profile->width,
                            pos_entry->profile->fontsize, pos_entry->profile->fontcolor, 
                            pos_entry->profile->shadowsize, pos_entry->profile->shadowcolor);
                
                snprintf(str,sizeof(str),
                         "echo \"%s, %s, %s\n\" >> %s",
                         pos_entry->ad_name, pos_entry->profile_name, pos_entry->ad_content,FP_DEBUG_LOG);
                system(str);*/
            }
            break; 
        }
        case DB_TYPE_PROFILE: /*profile*/
        {
            fp_profile_t *pos_entry = NULL;

            printf("\n---profile db---\n");
            list_for_each(pos, head) {
                pos_entry = list_entry(pos, fp_profile_t, node);
                printf("profile_name: %s, start_x: %d, start_y: %d, width: %d, fontsize: %d, fontcolor: %d, shadowsize: %d, shadowcolor: %d\n", 
                    pos_entry->profile_name, pos_entry->start_x, pos_entry->start_y, pos_entry->width,
                    pos_entry->fontsize, pos_entry->fontcolor, pos_entry->shadowsize, pos_entry->shadowcolor);
            }
            break; 
        }
    }
    
    return;
}

void fp_ol_avfree_db(struct list_head *head, int type)
{
    struct list_head *pos, *tmp;
    
    if(list_empty(head)) 
        return;

    list_for_each_safe(pos, tmp, head) {
        switch(type)
        {
            case DB_TYPE_SCHEDULE: 
            {
                fp_schedule_t *pos_entry = NULL; 

                pos_entry = list_entry(pos, fp_schedule_t, node);
                if(pos_entry->ad_name)
                    free(pos_entry->ad_name);
                if(pos_entry->profile_name)
                    free(pos_entry->profile_name);
                if(pos_entry->ad_content)
                    free(pos_entry->ad_content);
                
                list_del_init(pos);
                free(pos_entry);
                break;
            }
            case DB_TYPE_PROFILE:
            {
                fp_profile_t *pos_entry = NULL; 

                pos_entry = list_entry(pos, fp_profile_t, node);
                if(pos_entry->profile_name)
                    free(pos_entry->profile_name);
                
                list_del_init(pos);
                free(pos_entry);
                break;
            }
        }

    }

    return;

}

int fp_ol_init_schedule_db()
{
    FILE *fd;
    char str[MAX_LEN_EACH_LINE];
    char *ptr;
    char *offset;
    char *retptr;
    int type;
    int strlenght;
    int buflen;
    fp_schedule_t *fpSchedule;
    struct list_head *head = NULL;

    fd = fopen(FP_SCHEDULE_FILE ,"r");
    if(fd == NULL) {
        printf("fopen (%s) is failed \n", FP_SCHEDULE_FILE);
        return -1;
    }
    
    memset(str, 0, MAX_LEN_EACH_LINE);
    retptr = fgets(str, MAX_LEN_EACH_LINE, fd);
    if( (!retptr) || (0 != strncmp(str, FP_SCHEDULE_IDENTIFIER, strlen(FP_SCHEDULE_IDENTIFIER))) )
    {
        printf("illegal schedule file \n");
        fclose(fd);
        return 0;
    }
   
    head = &fpScheduledb;
    while(1)
    {
        memset(str, 0, MAX_LEN_EACH_LINE);
        retptr = fgets(str, MAX_LEN_EACH_LINE, fd);
        if(!retptr)
            break;

        offset = index(str, '\n');
        if(offset)
            *offset = 0;
        //printf("%s\n", str);
        
        if(*str == '#') /*skip note line*/
            continue;
    
        strlenght = 0;
        buflen = 0;
        type = 0;
        offset = str;
        fpSchedule = (fp_schedule_t *)malloc(sizeof(fp_schedule_t));
        memset(fpSchedule, 0, sizeof(fp_schedule_t));
    
        while(offset)
        {
            ptr = fp_ol_partingstr(&offset, "\"", &strlenght);
            if(!ptr) 
                break;
            buflen = strlenght +1;
      
            switch (type)
            {
                case 0: /*ad_name*/
                    fpSchedule->ad_name = malloc(buflen);
                    memset(fpSchedule->ad_name, 0, buflen);
                    memcpy(fpSchedule->ad_name, ptr, strlenght);
                    break; 
                case 1: /*profile_name*/
                    fpSchedule->profile_name = malloc(buflen);
                    memset(fpSchedule->profile_name, 0, buflen);
                    memcpy(fpSchedule->profile_name, ptr, strlenght);
                    
                    fp_ol_search_profile(fpSchedule->profile_name, &(fpSchedule->profile));
                    break; 
                case 2: /*ad_contetn*/
                    fpSchedule->ad_content = malloc(buflen);
                    memset(fpSchedule->ad_content, 0, buflen);
                    memcpy(fpSchedule->ad_content, ptr, strlenght);
                    break;
                default:
                    break;
            }
            type++;
        }
        list_add_tail( &(fpSchedule->node), head);
    } //end of while(1)


    fclose(fd);

    return 0;
}

int fp_ol_init_profile_db()
{
    FILE *fd;
    char str[MAX_LEN_EACH_LINE];
    char *ptr;
    char *offset;
    char *retptr;
    int type;
    int strlen;
    int buflen;
    char tempbuf[MAX_INT_LEN];
    fp_profile_t *fpProfile;
    struct list_head *head = NULL;

    fd = fopen(FP_PROFILE_FILE ,"r");
    if(fd == NULL) {
        printf("fopen (%s) is failed \n", FP_PROFILE_FILE);
        return -1;
    }
   
    head = &fpProfiledb;
    while(1)
    {
        memset(str, 0, MAX_LEN_EACH_LINE);
        retptr = fgets(str, MAX_LEN_EACH_LINE, fd);
        if(!retptr)
            break;

        offset = index(str, '\n');
        if(offset)
            *offset = 0;
        //printf("%s\n", str);
        
        if(*str == '#') /*skip note line*/
            continue;
    
        strlen = 0;
        buflen = 0;
        type = 0;
        offset = str;
        fpProfile = (fp_profile_t *)malloc(sizeof(fp_profile_t));
        memset(fpProfile, 0, sizeof(fp_profile_t));
    
        while(offset)
        {
            ptr = fp_ol_partingstr(&offset, "\"", &strlen);
            if(!ptr) 
                break;
            buflen = strlen +1;
      
            switch (type)
            {
                case 0: /*profile_name*/
                    fpProfile->profile_name = malloc(buflen);
                    memset(fpProfile->profile_name, 0, buflen);
                    memcpy(fpProfile->profile_name, ptr, strlen);
                    break; 
                case 1: /*start_x*/
                    memset(tempbuf, 0, MAX_INT_LEN);
                    memcpy( tempbuf, ptr, strlen);
                    fpProfile->start_x = atoi(tempbuf);
                    break; 
                case 2: /*start_y*/
                    memset(tempbuf, 0, MAX_INT_LEN);
                    memcpy( tempbuf, ptr, strlen);
                    fpProfile->start_y = atoi(tempbuf);
                    break; 
                case 3: /*width*/
                    memset(tempbuf, 0, MAX_INT_LEN);
                    memcpy( tempbuf, ptr, strlen);
                    fpProfile->width = atoi(tempbuf);
                    break; 
                case 4: /*fontsize*/
                    memset(tempbuf, 0, MAX_INT_LEN);
                    memcpy( tempbuf, ptr, strlen);
                    fpProfile->fontsize = atoi(tempbuf);
                    break; 
                case 5: /*fontcolor*/
                    memset(tempbuf, 0, MAX_INT_LEN);
                    memcpy( tempbuf, ptr, strlen);
                    fpProfile->fontcolor = atoi(tempbuf);
                    break; 
                case 6: /*shadowsize*/
                    memset(tempbuf, 0, MAX_INT_LEN);
                    memcpy( tempbuf, ptr, strlen);
                    fpProfile->shadowsize = atoi(tempbuf);
                    break; 
                case 7: /*shadowcolor*/
                    memset(tempbuf, 0, MAX_INT_LEN);
                    memcpy( tempbuf, ptr, strlen);
                    fpProfile->shadowcolor = atoi(tempbuf);
                    break; 
                default:
                    break;
            }
            type++;
        }
        list_add_tail( &(fpProfile->node), head);
    } //end of while(1)


    fclose(fd);

    return 0;
}

int main()
{

    INIT_LIST_HEAD(&fpScheduledb);
    INIT_LIST_HEAD(&fpProfiledb);

    fp_ol_init_schedule_db();
    //fp_ol_init_profile_db();

    fp_ol_display_db(&fpScheduledb, DB_TYPE_SCHEDULE);
    //fp_ol_display_db(&fpProfiledb, DB_TYPE_PROFILE);

    //fp_ol_avfree_db(&fpScheduledb, DB_TYPE_SCHEDULE);
    //fp_ol_avfree_db(&fpProfiledb, DB_TYPE_PROFILE);
    
    //fp_ol_display_db(&fpScheduledb, DB_TYPE_SCHEDULE);
    //fp_ol_display_db(&fpProfiledb, DB_TYPE_PROFILE);
    return 0;
}
