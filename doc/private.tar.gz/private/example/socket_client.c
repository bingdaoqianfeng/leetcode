#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <arpa/inet.h>
#include <unistd.h>

#define SERVPORT 5000 /*port number of server listern*/
#define BACKLOG 10 /* max connect number */
/*
struct sockaddr_in {  
　　 short int sin_family;   
　　 unsigned short int sin_port;   
　　 struct in_addr sin_addr;    
　　 unsigned char sin_zero[8];    
　　 };  
*/

int main()
{
    int sockfd; 
    struct sockaddr_in send_addr;  
    char buf[] = "hello world , ok ....!";
    int numbytes = 0;
    
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
        printf("failed to create socket\n"); 
        return 0;
    }
    
    /*init client*/
    send_addr.sin_family=AF_INET;
    send_addr.sin_port=htons(SERVPORT); /*make port is network byte order*/
    //send_addr.sin_addr.s_addr = INADDR_ANY;
    send_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    bzero(&(send_addr.sin_zero),8);
    
    while(1) {
        if ((numbytes=sendto(sockfd, buf, strlen(buf), 0, (struct sockaddr *)&send_addr, sizeof(struct sockaddr))) == -1) {  
            printf("failed to sendto \n");  
            close(sockfd);
            exit(1);  
        }  
        printf("sent %d bytes to %s\n",numbytes,inet_ntoa(send_addr.sin_addr)); 
        printf("send buf: %s\n", buf);
        sleep(1);
    }

    
    return 0;
}
