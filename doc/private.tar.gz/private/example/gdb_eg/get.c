#include   <stdio.h>  
#include   "get.h"  

static   int   x=0;  
int   get   ()  
{  
    printf("get   x=%d\n",   x);  
    return   x;  
} 

int set(int   a)  
{
    char *str="adsds";
    printf("set   a=%d\n",   a);  
    x = a;  

    *str = 'a';
    return x;  
} 
