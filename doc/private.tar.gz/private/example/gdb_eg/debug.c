#include   <stdio.h>  
#include   <dlfcn.h>
#include <string.h>

/* Function must be called 'Configure' */
typedef int (FrameHookConfigure)(void **ctxp, int argc, char *argv[],void (*ol_fp)(int vhook_id), int vhook_id);
typedef FrameHookConfigure *FrameHookConfigureFn;

FrameHookConfigureFn Configure;
void *ctx;

int main()  
{  
    void *loaded;
    int argc = 0;
    char *argv[64];
    int i;
    char args[] = "/mnt/yuvad/encoder/pic_in_pic.so;-eenable;-x44;-y502;";
    
    argv[0] = strtok(args, ";");
    while (argc < 62 && (argv[++argc] = strtok(NULL, ";"))) {  }

    loaded = dlopen("/home/yxliu/DROCK-2.4/transcode/3rdparty/ffmpeg_r17768/vhook/pic_in_pic.so", RTLD_NOW);
    if (!loaded) {
        printf("%s\n", dlerror());
        return -1;
    }
    
    Configure = dlsym(loaded, "Configure");

    Configure(&ctx, argc, argv, NULL, 1);

    return   0;  
}
