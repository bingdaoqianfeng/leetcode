#include   <stdio.h>  
#include   <dlfcn.h>

typedef int (*register_get) ();
typedef int (*register_set) (int a);

int main(int   argc,   char**   argv)  
{  
    void *loaded;
    register_get get_p;
    register_set set_p;

    loaded = dlopen("/home/yxliu/example/gdb_eg/libget.so", RTLD_NOW);
    if (!loaded) {
        printf("%s\n", dlerror());
        return -1;
    }
    
    get_p = dlsym(loaded, "get");
    set_p = dlsym(loaded, "set");

    int a = get_p();
    int b = set_p(2);

    return   0;  
}
