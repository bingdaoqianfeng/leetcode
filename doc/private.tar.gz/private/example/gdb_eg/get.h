int get();
int set(int a);

