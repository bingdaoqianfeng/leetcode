#!/bin/sh
offline_testcase_path=/offline/test_cases
offline_xml_exp=/offline/example_xml/offline_xml.exp
offline_port=23

usage() {
	echo "ol_multi_server.sh [channel_name] <showplaylist|showtrlist|auto|manual|mode|activate|deactivate|status|updatemedia|updateprofile|updatetr|updatetextone|updategraphicone|updategraphictwo|tvlogo|tvlogostatus>"
	echo "if there is no channel_name argument, the script will be applied to all channel in system. "
	echo "if channel_name is a specific channel name, e.g "CCTV_1", the script will just be applied to the specific channel. "
	exit 1
}


#set a special_channel which name is $ol_channel_name
add_one_xml_test_case() {

	xml_file_name=$1
    xml_cmmand="add_request"
    #echo $offline_port $xml_cmmand $xml_file_name 
	
	
	#telnet transcode_tool 
	$offline_xml_exp $offline_port $xml_cmmand $xml_file_name
}


add_all_xml_test_case() {
	for ch in `ls $offline_testcase_path/*.xml `; do
        add_one_xml_test_case $ch
    done  
	exit 0
}

######################
# main loop start
######################

add_all_xml_test_case
