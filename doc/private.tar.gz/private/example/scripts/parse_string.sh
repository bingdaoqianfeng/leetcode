#!/bin/bash
input_file="ftp://username:password@host:port/path/file"
#input_file="FTP://username:password@host:port/path/file"

strint_length() {
    string=$1
    position=`expr index "$string" ":"`
    echo $position
}

#if input is ftp, return 0
#otherwise, return 1
check_ftp() {
    string=$1
    file_type=${string:0:6}
    #echo $file_type

    if [ $file_type = "ftp://" ] || [ $file_type = "FTP://" ]; then
        #echo "it is ftp source file"
        return 0
    else
        return 1
    fi

}

parse_ftp() {
    string=$1
    echo "string=$string"

    #get ftp username
    tempstring=${string#ftp://}
    #echo "tempstring=$tempstring"
    let len=`expr index "$tempstring" ":"`-1 
    username=${tempstring:0:$len}
    echo "username=$username"

    #get_ftp password
    let len=$len+1
    tempstring=${tempstring:$len}
    #echo "tempstring=$tempstring"
    let len=`expr index "$tempstring" "@"`-1 
    password=${tempstring:0:$len}
    echo "password=$password"

    #get ftp host addr
    let len=$len+1
    tempstring=${tempstring:$len}
    #echo "tempstring=$tempstring"
    let len=`expr index "$tempstring" ":"`-1 
    host=${tempstring:0:$len}
    echo "host=$host"

    #get ftp port
    let len=$len+1
    tempstring=${tempstring:$len}
    #echo "tempstring=$tempstring"
    let len=`expr index "$tempstring" "/"`-1 
    port=${tempstring:0:$len}
    echo "port=$port"
    
    #get ftp filename
    tempstring=${tempstring:$len}
    #echo "tempstring=$tempstring"
    file=$tempstring
    echo "file=$file"
}

check_ftp $input_file
if [ $? -eq 1 ]; then
    echo "input is not ftp file"
    exit 1
fi

parse_ftp $input_file
