#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Imlib2.h>

static int get_text_property(char *text, char *fontpath, int fontsize)
{
    Imlib_Image image;
    int text_width;
    int text_height;
    int offset;
    int scalewidth = 0;
    static int i=0;
    int fonttype = 1;
    int bordersize = 5;
    int bordercolor = 13369548;
    int fontcolor = 16764108;
    int boldsize = 0;
    
    //printf("---text: %s---\n", text);
    //printf("---fontsize: %d, fontpath: %s---\n",fontsize, fontpath);
    image = yuvad_load_text_image( fontpath, fontsize,
                                   text, &text_width, &text_height,
                                   &offset, scalewidth,
                                   fonttype, fontcolor, bordercolor,
                                   bordersize, boldsize);
    
    if( !image ) {
        printf("error when log image\n");
        return -1;
    }
    else {
        printf("---%d: text_width: %d, text_height: %d---\n", i++, text_width, text_height);
   	if(image) {
            imlib_context_set_image(image);
            imlib_free_image();
        }
   }
    
    return 0;
}

int main()
{
    char fontpath[] = "/home/yxliu/DROCK-2.4/transcode/overlay/fonts/gkai00mp.ttf";
    int fontsize = 30;
    char text[] = "fggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg";

    while(1) {
        if(-1 == get_text_property(text, fontpath, fontsize))
            break;
    }

    return 0;
}
