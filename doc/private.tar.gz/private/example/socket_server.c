#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>

#define SERVPORT 5000 /*port number of server listern*/
/*
struct sockaddr_in {  
　　 short int sin_family;   
　　 unsigned short int sin_port;   
　　 struct in_addr sin_addr;    
　　 unsigned char sin_zero[8];    
　　 };  
*/

int main()
{
    int sockfd; 
    struct sockaddr_in my_addr; 
    char buf[128];
    int numbytes = 0;
    struct sockaddr_in remote_addr; 
    int addr_len;
    fd_set readfds;
    struct  timeval timeout = {2, 0}; /*wait for 3 second*/

    addr_len = sizeof(remote_addr); 
    
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
        printf("failed to create socket\n"); 
        return 0;
    }
    
    /*init server*/
    my_addr.sin_family=AF_INET;
    my_addr.sin_port=htons(SERVPORT); /*make port is network byte order*/
    //my_addr.sin_addr.s_addr = INADDR_ANY;
    my_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    bzero(&(my_addr.sin_zero),8);
    bzero(&(remote_addr.sin_zero),8);
    
    if (bind(sockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1) {
        printf("failed to bind socket\n");
        return 0;
    }
    //fcntl(sockfd, F_SETFL, O_NDELAY); 
    
    while(1) {
        FD_ZERO(&readfds);
        FD_SET(sockfd, &readfds);
        
        switch (select(sockfd + 1, &readfds, NULL, NULL, &timeout)) {
            case -1:
                printf("select error\n");
                break;
            case 0:
                printf("receive timeout\n");
                break;
            default:
                if(FD_ISSET(sockfd,&readfds)) {
                    memset(buf, 0, sizeof(buf));
                    numbytes = recvfrom(sockfd, buf, 1024, 0, (struct sockaddr *)&remote_addr, (socklen_t *)&addr_len);  
                    if(numbytes == -1) {  
                        printf("failed to receive from  \n"); 
                        perror("recvfrom");
                    }  
                    printf("receive %d bytes from %s, port: %d\n",numbytes,inet_ntoa(remote_addr.sin_addr), ntohs(remote_addr.sin_port));
                    printf("receive buf: %s\n", buf);
                }
                break;
        }
        timeout.tv_sec = 3;
        timeout.tv_usec = 0;
    }

    
    return 0;
}
