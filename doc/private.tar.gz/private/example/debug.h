#ifndef YUVAD_DEBUG_H
#define YUVAD_DEBUG_H
#include <stdio.h>
#include <syslog.h>

#define DEBUG_ON 1

#if DEBUG_ON

#define dbg_msg(x...) do { \
    fprintf(stderr, x); \
    syslog(LOG_LOCAL1|LOG_DEBUG, x); \
} while (0)

#else

#define dbg_msg(x...) do {} while(0)

#endif

#define warn_msg(x...) do { \
    fprintf(stderr, x); \
    syslog(LOG_LOCAL1|LOG_DEBUG, x); \
} while (0)

#define err_msg(x...) do { \
    fprintf(stderr, x); \
    syslog(LOG_LOCAL1|LOG_DEBUG, x); \
} while (0)

#define dbg_assert(expr) do { \
    if (!(expr)) { \
        err_msg("assertion failure at file %s line %d: %s\n", \
                __FILE__, __LINE__, #expr); \
    } \
} while (0)

#endif
