#include <stdlib.h>
#include <stdio.h>
#include <string.h>

typedef struct {
    int a;
    int b;
    int c;
}node_one_t;

typedef struct {
    char name[128];
    int id;
    char type[128];
}node_two_t;

int main()
{
    node_one_t one;
    node_two_t two;
    char *src, *dst;

    one.a = 1;
    one.b = 2;
    one.c = 3;

    strcpy(two.name, "hello world");
    two.id = 1234;
    strcpy(two.type, "test for pointer");

    src = (char *)&one;
    dst = (char *)malloc(sizeof(node_one_t));
    *(node_one_t *)dst = *(node_one_t *)src;
    printf("a: %d, b: %d, c: %d\n",
            ((node_one_t *)dst)->a, ((node_one_t *)dst)->b, ((node_one_t *)dst)->c);

    src = (char *)&two;
    dst = (char *)malloc(sizeof(node_two_t));
    *(node_two_t *)dst = *(node_two_t *)src;
    printf("name: %s, id: %d, type: %s\n",
            ((node_two_t *)dst)->name, ((node_two_t *)dst)->id, ((node_two_t *)dst)->type);

    return 0;
}
