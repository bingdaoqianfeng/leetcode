#include <pthread.h>
#include <stdlib.h>
#include <string.h>

#include "task_mgt.h"

tm_request_queue_t pendingList[PRIORITY_QUEUE_NUM];
tm_request_queue_t finishedList;
tm_request_queue_t handlingList;


static int tm_copy_list(struct list_head *dstList, struct list_head *srcList, tm_list_type_t type)
{
    struct list_head *pos, *tmp;
    char *srcNode, *dstNode;
    
    if(list_empty(srcList)) {
        return 0;
    }    
        
    list_for_each_safe(pos, tmp, srcList) {
        switch(type) {
            case OUTPUT_LIST:
                srcNode = (char *)list_entry(pos, ot_output_t, node);
                dstNode = (char *)malloc(sizeof(ot_output_t));
                if(!dstNode) {
                    dbg_msg("ERROR: can not alloc memory for new outputNode\n");
                    /*free dstList and return error*/
                    return -1;
                }
                memset((char *)dstNode, 0, sizeof(ot_output_t));
                
                *(ot_output_t *)dstNode = *(ot_output_t *)srcNode;
                list_add_tail( &(((ot_output_t *)dstNode)->node),dstList);
                break;
            case INPUT_LIST:
                srcNode = (char *)list_entry(pos, ot_input_t, node);
                dstNode = (char *)malloc(sizeof(ot_input_t));
                if(!dstNode) {
                    dbg_msg("ERROR: can not alloc memory for new outputNode\n");
                    /*free dstList and return error*/
                    return -1;
                }
                memset((char *)dstNode, 0, sizeof(ot_input_t));
                
                *(ot_input_t *)dstNode = *(ot_input_t *)srcNode;
                list_add_tail( &(((ot_input_t *)dstNode)->node),dstList);
                break;
            case TASK_LIST:
                srcNode = (char *)list_entry(pos, tm_task_node_t, node);
                dstNode = (char *)malloc(sizeof(tm_task_node_t));
                if(!dstNode) {
                    dbg_msg("ERROR: can not alloc memory for new outputNode\n");
                    /*free dstList and return error*/
                    return -1;
                }
                memset((char *)dstNode, 0, sizeof(tm_task_node_t));
                
                *(tm_task_node_t *)dstNode = *(tm_task_node_t *)srcNode;
                list_add_tail( &(((tm_task_node_t *)dstNode)->node),dstList);
                break;
        }
    }

    return 0;
}



/*
*insert request into list
*/
static tm_request_node_t *tm_copy_request_node(ot_request_t *request)
{
    tm_request_node_t *tmRequest = NULL;

    tmRequest = (tm_request_node_t *)malloc(sizeof(tm_request_node_t));
    if(!tmRequest) {
        dbg_msg("ERROR: can not alloc memory for new requestNode\n");
        return NULL;
    }
    memset((char *)tmRequest, 0, sizeof(tm_request_node_t));
   
    /*init list*/
    INIT_LIST_HEAD(&tmRequest->input_list);
    INIT_LIST_HEAD(&tmRequest->output_list);
    INIT_LIST_HEAD(&tmRequest->task_list);

    /*copy input list*/
    tm_copy_list(&tmRequest->input_list, &request->input_list, INPUT_LIST);

    /*copy output list*/
    tm_copy_list(&tmRequest->output_list, &request->output_list, OUTPUT_LIST);
    
    /*copy task list*/
    tm_copy_list(&tmRequest->task_list, &request->task_list, TASK_LIST);

    return tmRequest;
}


/*the following function are extern function which will called by configure management*/

void tm_init_task_management()
{
    int i;

    /*init total list*/
    for(i=0; i<PRIORITY_QUEUE_NUM; i++) {
        INIT_LIST_HEAD(&pendingList[i].list);
        pthread_mutex_init(&pendingList[i].lock, NULL);
    }
    
    /*init finished list*/
    INIT_LIST_HEAD(&finishedList.list);
    pthread_mutex_init(&finishedList.lock, NULL);
    
    /*init running list*/
    INIT_LIST_HEAD(&handlingList.list);
    pthread_mutex_init(&handlingList.lock, NULL);
    

    /*init socket*/

    return;
}

/*add request which may have many task into queue.
*input argument:
*               item: request struct
*               flag: 
*                       0: not sync
*                       1: sync
*
*return value:  successful:  requrieID
*               failed: -1
*
*related module:
*           configure management module
*           cluster management module
*/
int tm_add_request( ot_request_t *request, int flag)
{
    struct list_head *head;
    tm_request_node_t *tmRequest;
    int priority;
    ot_status_t status;   

    priority = request->priority;
    status= request->status;
    
    switch(status) {
        case PENDING:
            head = &pendingList[priority].list;
            break;
        case FINISHED:
            head = &finishedList.list;
            break;
        case HANDLING:
            head = &handlingList.list;
            break;
    }
        
    /*Insert new request into list*/
    tmRequest = tm_copy_request_node(request);

    if(flag) { /*need to sync*/
        switch(status) {
            case PENDING:
                /*Call interface of configure management to delete total list configure file*/
    
                /*Call interface of configure management to create new total list configure file according to the latest total queue*/
    
                /*Call interface of cluster management to synchronized total list configure file with other cluster*/
                break;
            case FINISHED:
                /*Call interface of configure management to delete finished list configure file*/
    
                /*Call interface of configure management to create new finished list configure file according to the latest finished queue*/
    
                /*Call interface of cluster management to synchronized finished list configure file with other cluster*/
                break;
            case HANDLING:
                /*extended interface*/
                break;
        }
    }

    return tmRequest->id;
}

#if 0

/*delete request according to requestID, flag and priority.
*
*input argument:
*               request ID: is -1, delete all  task status
*                           is >=0, get the request status
*               priority: the argument will come into effect whne request ID is -1.
*                         if the prority is -1, it will get all request status,
*                         else it will just get request status according to priority.
*               flag: 
*                     0: delete all request
*                     1: just delete finished request
*                     2: just delete running request     
*                     3: just delete waiting request
*return value:
*            0: successful;
*            -1: failed
*
*related module:
*           configure management module
*           cluster management module
*/
int del_request(int requestID, int priority, int flag)
{
    int i;
    struct list_head *head;
    
    /*search request in queue depend on requestID*/
    head = &requestQueue[i].list;
    
    /*if not found the request, return -1*/

    /*if found the request*/
    switch(request.status) {
        case: /*if the request is running*/
            /*send command to cluster management to stop the task and remove output file of the task and so on,
            * waiting for response from cluster management */
            
            /*if stop the task is failed, need to deal with the error, and return*/

            /*if stop the task is ok, will remove it from queue*/

            break;
        case: /*if the request has finished, include really finished and error*/
        case: /*if the request is waiting for scheduling*/
            /*delete the request from queue*/
            
            break;
    }
            
    /*Call interface of configure management to delete task list configure file*/
    
    /*Call interface of configure management to create new task list configure file depend on the latest queue*/
    
    /*Call interface of cluster management to synchronized task list configure file with other cluster*/

    return 0;
}

/*get status of request which has been divided into atomic task, 
*the function should return every status of atomic task. 
*
*input argument:
*               request ID: is -1, get all task status
*                           is >=0, get the request status
*               priority: the argument will come into effect whne request ID is -1.
*                         if the prority is -1, it will get all request status,
*                         else it will just get request status according to priority.
*               flag: 
*                     0: get all task status
*                     1: just get finished task status
*                     2: just get running task status     
*                     3: just get waiting task  status
*
*return value:
*           successful; head is pointer which point to status list,
*                       the status list will be free in configure management to call free_status()
*                       which is define by task management.
*                       status include: finished | transcoding | waiting
*           failed: NULL
*
*related module:
*           configure management module
*/
status_struct *int get_status(int requestID, int priority, int flag)
{
    status_struct *head;

    if(requestID != -1) { /*just get one request status*/
       /*search request in queue according to requestID*/

       if() { /*didn't find the request in queue, return -1*/
            return -1;
        }
        else { /*found the request in queue*/
            /*allocate memory for request, the request will include a task_list queue.*/
            
            while() { /*walk through the entire atomic task list*/
                /*allocate memory for one atomic task to save status*/

                /*insert the task tatus into task_list*/
            }
            
            /*insert the request tatus into statust_list*/
        }
    }
    else { /*get all request status*/
        while() { /*walk through the entire queue according to priority*/
            /*allocate memory for the request, the request will include a task_list queue.*/
            
            while() { /*walk through the entire atomic task list*/
                /*allocate memory for one atomic task to save status*/

                /*insert the task tatus into task_list*/
            }
            
            /*insert the request tatus into statust_list*/
        }
    }

    return 0;
}


/*get every task progress of specific request
*
*input argument:
*               request ID: must be >=0
*return value:
*           successful: head is pointer which point to progress list which have a sublist poinging to task_progress_list
*                       the status list will be free in configure management to call free_progress()
*                       which is define by task management.
*                       execution progress will display as a percentage.
*           failed: NULL
*
*related module:
*           configure management module
*           cluster management module
*/
progress_struct *get_progress( int requestID )
{
    progress_struct *head;
    
    
    /*search request in queue according to request ID*/

    if(){ /*didn't find then request*/
        return -1;
    }

    while() { /*walk through atomic task list*/
        /*allocate memory for task progress.*/
        
        switch(task_staus) {
            case : /*waiting for scheduling*/
                /*progress is 0%*/
                break;
            case : /*finished*/
                /*progress is 100%*/
                break;
            case : /*waiting for scheduling*/
                /*send command to cluster management to get progress of the task*/
                break;
        }

        /*insert task progress into progress_list*/
    }

    /*calculate the progress of the entire task*/


    return 0;
}

/*
* description: free status list 
*/
int free_status(status_struct *head)
{
    if(head == NULL) {
        return 0;
    }

    return 0;
}

/*
* description: free progress list 
*/
int free_progress( progress_struct *head)
{
    return 0;
}

#endif
