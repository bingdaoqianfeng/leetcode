#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>


void redirect_stderr()
{
    char app[BUFSIZ];
    char log[BUFSIZ];
    int count;
    char *p;
    FILE *fp;
    
    printf("BUFSIZ: %d\n", BUFSIZ);
    
    /*get save path of the current process*/
    memset(app, 0, sizeof(app));
    count = readlink("/proc/self/exe", app, sizeof(app) - 1); 
    if (count < 0 || count > BUFSIZ ) {
        printf("%s: readlink '/proc/self/exe' error %d - %s\n", __func__, errno, strerror(errno));
        return;
    }
    printf( "/proc/self/exe -> [%s]\n", app );

    /*get name of the current process*/
    p = app + strlen(app);
    while ((p != app) && (*(p-1) != '/'))
        p--;
    
    /*redirect stderr to /var/log/process_name*/
    snprintf(log, sizeof(log), "/var/log/%s.log", p);
    printf("log: %s\n", log);
    fflush(stderr);
    
    if ((fp = freopen(log, "a", stderr)) == NULL)  
        printf("%s: freopen %s error %d - %s\n", __func__, log, errno, strerror(errno));
    else {
        setlinebuf(fp);
        stderr = fp;
    }

    return;
}

int main()
{
    redirect_stderr();

    return 0;
}
