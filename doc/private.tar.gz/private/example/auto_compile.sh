#!/bin/sh
#nohup ./auto_compile.sh &

svn co svn://192.168.0.32/release_branches/DROCK-3.0/ /home/yxliu/DROCK-3.0

cd /home/yxliu/DROCK-3.0

sudo make install
