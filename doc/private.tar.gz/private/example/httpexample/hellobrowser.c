#include <platform.h>
#include <microhttpd.h>

#define PORT 8888

int print_out_key (void *cls, enum MHD_ValueKind kind, const char *key, const char *value)
{
    printf ("---------------------------------------\n");
    printf ("%s = %s\n", key, value);
    printf ("---------------------------------------\n");
    return MHD_YES;
}

int answer_to_connection (void *cls, struct MHD_Connection *connection,
                      const char *url, const char *method,
                      const char *version, const char *upload_data,
                      size_t *upload_data_size, void **con_cls)
{
    //const char *page = "<html><body>Hello, browser!</body></html>";
    const char *page = "<html><head><title>libmicrohttpd demo</title></head><body>libmicrohttpd demo</body></html>";
    struct MHD_Response *response;
    int ret;

    static int aptr;
    
    if(url)
        printf("url: %s\n", url);
    if(method)
        printf("method: %s\n", method);
    if(version)
        printf("version: %s\n", version);
    if(upload_data)
        printf("upload_data: %s\n", upload_data);

    //MHD_get_connection_values (connection, MHD_HEADER_KIND, print_out_key, NULL);
    
    #if 1
    if (&aptr != *con_cls)
    {
        /* do never respond on first call */
        *con_cls = &aptr;
        return MHD_YES;
    }
    *con_cls = NULL;  /* reset when done */
    #endif
    
    response = MHD_create_response_from_data(strlen(page), (void *)page, MHD_NO, MHD_NO);
    ret = MHD_queue_response (connection, MHD_HTTP_OK, response);
    MHD_destroy_response (response);
    
    printf("MHD_YES: %d, MHD_NO: %d, ret: %d\n", MHD_YES, MHD_NO, ret);
        
    return ret;
}

int main ()
{
    struct MHD_Daemon *daemon;
    
    daemon = MHD_start_daemon (MHD_USE_SELECT_INTERNALLY, PORT, NULL, NULL,
                             &answer_to_connection, NULL, MHD_OPTION_END);
                             
    if (NULL == daemon)
        return 1;
    
    getchar ();
    MHD_stop_daemon (daemon);
    
    return 0;
}
