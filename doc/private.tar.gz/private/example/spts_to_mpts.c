#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define INPUT_FILE_NUMBER  4
#define READ_SECTION_LEN    188

int merge_files_into_one_file(char *input_file[], char *output_file)
{
    FILE *in_fd[INPUT_FILE_NUMBER];
    FILE *out_fd;
    int i, j;
    char buf[255];
    int len;
    int flag[INPUT_FILE_NUMBER];

    out_fd = fopen(output_file ,"w");
    if(out_fd == NULL)
    {
        printf("open %s failed\n",output_file);
        return -1;
    }
    for(i=0; i<INPUT_FILE_NUMBER; i++)
    {
        in_fd[i] = fopen(input_file[i] ,"r");
        if(in_fd[i] == NULL)
        {
            printf("open %s failed\n",input_file[i]);
            return -1;
        }

        flag[i] = 0;
    }
    
    i = 0;
    while(1)
    {
        switch(i)
        {
            case 0:
                if(flag[i]) 
                {
                    i++;
                    break;
                }
                memset(buf, 0, sizeof(buf));
                len = fread(buf, 1, READ_SECTION_LEN, in_fd[i]);
                if(len < READ_SECTION_LEN)
                {
                    fwrite(buf, 1, len, out_fd); 
                    fclose(in_fd[i]);
                    flag[i] = 1;
                }
                else 
                {
                    fwrite(buf, 1, len, out_fd); 
                }
                i++;
                break;
            case 1:
                if(flag[i]) 
                {
                    i++;
                    break;
                }
                memset(buf, 0, sizeof(buf));
                len = fread(buf, 1, READ_SECTION_LEN, in_fd[i]);
                if(len < READ_SECTION_LEN)
                {
                    fwrite(buf, 1, len, out_fd); 
                    fclose(in_fd[i]);
                    flag[i] = 1;
                }
                else 
                {
                    fwrite(buf, 1, len, out_fd); 
                }
                i++;
                break;
            case 2:
                if(flag[i]) 
                {
                    i++;
                    break;
                }
                memset(buf, 0, sizeof(buf));
                len = fread(buf, 1, READ_SECTION_LEN, in_fd[i]);
                if(len < READ_SECTION_LEN)
                {
                    fwrite(buf, 1, len, out_fd); 
                    fclose(in_fd[i]);
                    flag[i] = 1;
                }
                else 
                {
                    fwrite(buf, 1, len, out_fd); 
                }
                i++;
                break;
            case 3:
                if(flag[i]) 
                {
                    i = 0;
                    break;
                }
                memset(buf, 0, sizeof(buf));
                len = fread(buf, 1, READ_SECTION_LEN, in_fd[i]);
                if(len < READ_SECTION_LEN)
                {
                    fwrite(buf, 1, len, out_fd); 
                    fclose(in_fd[i]);
                    flag[i] = 1;
                }
                else 
                {
                    fwrite(buf, 1, len, out_fd); 
                }
                i = 0;
                break;
        }//end of switch

        for(j=0; j<INPUT_FILE_NUMBER; j++)
        {
            if(!flag[j])
                break;
        }
        if(j == INPUT_FILE_NUMBER)
        {
            printf("convert is finished\n");
            break;
        }
    }

    return 0;
}

int main(int argc, char *argv[])
{   
    char *output_file;
    char *input_file[INPUT_FILE_NUMBER];
    int i;

    printf("argc: %d\n", argc);
    if(argc != 6)
    {
        printf("input argument error!\n");
        return -1;
    }

    output_file = strdup(argv[1]);
    for(i=0; i<INPUT_FILE_NUMBER; i++)  {
        input_file[i] = strdup(argv[i+2]);
    }
    printf("output_file: %s\n", output_file);
    for(i=0; i<INPUT_FILE_NUMBER; i++)  {
        printf("input_file_%d: %s\n", i+1, input_file[i]);
    }
    
    merge_files_into_one_file(input_file, output_file);

    return 0;
}

