/*
* create xml file depend on configure file
*/
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <libxml/parser.h>
#include <libxml/tree.h>
#include "./debug.h"

typedef struct{
    /*xml file name*/
    char *filename;

    /*input*/
    char input_file_name[256];
    char input_type[32];    /*file, dvd, directory*/
    char input_fmt[32];     /*auto, dvd*/
    int dvd_title;

    /*output*/
    char output_file_name[256];
    char output_fmt[32];

    /* video parameter */
    char v_type[32];        /*video codec*/
    char v_profile[32];     /*video profile*/
    char v_level[32];       /*video level*/
    char rc_mode[16];
    char output_size[16];
    char aspect[16];
    char bitrate[16];
    char max_bitrate[16];
    int32_t iframe_interval;    /*video_keyint*/
    char fps[32];
    int32_t bframes;
    char deinterlace[16];
    char interlaced[16];
    char field_order[32];
    char scenecut[16];

    /* audio parameter */
    char a_type[32];        /*audio_codec: mp2, mp3, aac_lc, aac_main, amr_nb, amr_wb, he_aac_v1, he_aac_v2, none*/
    char a_bitrate[16];
    int32_t volume;         /*integer type, (0, 100) percentage,  78 is default which don't change anything*/
    char channel_mode[32];  /*mono, stereo, onlyleftchannel, onlyrightchannel*/
    int32_t channels;       /*1, 2*/
    int32_t sample_rate;    /*for mp2, mp3, it's 32000, 44100, 48000
                              for aac_lc, aac_main, it's 16000, 24000, 32000, 44100, 48000
                              for amr_nb, it's 8000
                              for amr_wb, it's 16000
                              for he_aac_v1, he_aac_v2, it's 32000, 44100, 48000
                            */
}request_node;

#define INPUT_PATH "/offline/upload/lmwang/offline/input"
#define OUTPUT_PATH "/offline/media/Media-Library/upload/yxliu/offline/output"
#define XML_PATH    "./test_cases"

#define INPUT_VIDEO_MPEG2   "s21-1.5M.ts"
#define INPUT_VIDEO_DVD_FILE   "VTS_01_1.VOB"
#define INPUT_VIDEO_DVD_IMAGE   "Elephants.Dream"
#define INPUT_VIDEO_MP4   "Envivio500.mp4"

#define INPUT_VIDEO_NUM     4

static request_node test_case[]=
{
    /*input file: mpeg, output file: h264 3gp */
    {"3gp_h264_baseline.xml", INPUT_VIDEO_MPEG2, "file", "auto", 0, 
     "3gp_h264_baseline.3gp", "3gp", 
     "h264", "baseline", "30", "cbr", "320x240", "4:3", "128000", "1404000", 50, "25", 3, "disable","enable", "top_field_first", "enable", 
     "aac_lc", "80000", 100, "mono", 1, 48000 },
    
    /*input file: mpeg, output file: h263 3gp */
    {"3gp_h263.xml", INPUT_VIDEO_MPEG2, "file", "auto", 0, 
     "3gp_h263.3gp", "3gp", 
     "h263", "baseline", "30", "cbr", "352x288", "4:3", "128000", "1404000", 50, "25", 3, "disable","enable", "top_field_first", "enable", 
     "aac_lc", "80000", 100, "mono", 1, 48000 },
    
    /*input file: mpeg, output file: mepg4 3gp */
    {"3gp_mpeg4.xml", INPUT_VIDEO_MPEG2, "file", "auto", 0, 
     "3gp_mpeg4.3gp", "3gp", 
     "mpeg4", "baseline", "30", "cbr", "320x240", "4:3", "128000", "1404000", 50, "25", 3, "disable","enable", "top_field_first", "enable", 
     "aac_lc", "80000", 100, "mono", 1, 48000 },
    
    /*input file: mpeg, output file: h.264 baseline ts*/
    {"ts_h264_baseline.xml", INPUT_VIDEO_MPEG2, "file", "auto", 0, 
     "ts_h264_baseline.ts", "ts", 
     "h264", "baseline", "30", "cbr", "720x576", "4:3", "15000000", "1404000", 50, "25", 3, "disable","enable", "top_field_first", "enable", 
     "mp2", "80000", 100, "stereo", 2, 48000 },
    
    /*input file: mpeg, output file: h.264 main ts*/
    {"ts_h264_main.xml", INPUT_VIDEO_MPEG2, "file", "auto", 0, 
     "ts_h264_main.ts", "ts", 
     "h264", "main", "30", "cbr", "720x576", "4:3", "15000000", "1404000", 50, "25", 3, "disable","enable", "top_field_first", "enable", 
     "mp2", "80000", 100, "stereo", 2, 48000 },
    
    /*input file: mpeg, output file: h.264 high ts*/
    {"ts_h264_high.xml", INPUT_VIDEO_MPEG2, "file", "auto", 0, 
     "ts_h264_high.ts", "ts", 
     "h264", "high", "30", "cbr", "720x576", "4:3", "15000000", "1404000", 50, "25", 3, "disable","enable", "top_field_first", "enable", 
     "mp2", "80000", 100, "stereo", 2, 48000 },
    
    /*input file: mpeg, output file: flv h.264 baseline, flv audio sampel must:(44100, 22050, 11025)*/
    {"flv_h264_baseline.xml", INPUT_VIDEO_MPEG2, "file", "auto", 0, 
     "flv_h264_baseline.flv", "flv", 
     "h264", "baseline", "30", "cbr", "352x288", "4:3", "700000", "1404000", 50, "25", 3, "disable","enable", "top_field_first", "enable", 
     "mp3", "80000", 100, "stereo", 2, 44100 },
    
    /*input file: mpeg, output file: flv h.264 main, flv audio sampel must:(44100, 22050, 11025)*/
    {"flv_h264_main.xml", INPUT_VIDEO_MPEG2, "file", "auto", 0, 
     "flv_h264_main.flv", "flv", 
     "h264", "main", "30", "cbr", "352x288", "4:3", "700000", "1404000", 50, "25", 3, "disable","enable", "top_field_first", "enable", 
     "mp3", "80000", 100, "stereo", 2, 44100 },
    
    /*input file: mpeg, output file: flv h.264 high, flv audio sampel must:(44100, 22050, 11025)*/
    {"flv_h264_high.xml", INPUT_VIDEO_MPEG2, "file", "auto", 0, 
     "flv_h264_high.flv", "flv", 
     "h264", "high", "30", "cbr", "352x288", "4:3", "700000", "1404000", 50, "25", 3, "disable","enable", "top_field_first", "enable", 
     "mp3", "80000", 100, "stereo", 2, 44100 },
    
    /*input file: mpeg, output file: mp4 h.264 baseline*/
    {"mp4_h264_baseline.xml", INPUT_VIDEO_MPEG2, "file", "auto", 0, 
     "mp4_h264_baseline.mp4", "mp4", 
     "h264", "baseline", "30", "cbr", "352x288", "4:3", "700000", "1404000", 50, "25", 3, "disable","enable", "top_field_first", "enable", 
     "mp3", "80000", 100, "stereo", 2, 44100 },
    
    /*input file: mpeg, output file: mp4 h.264 main*/
    {"mp4_h264_main.xml", INPUT_VIDEO_MPEG2, "file", "auto", 0, 
     "mp4_h264_main.mp4", "mp4", 
     "h264", "main", "30", "cbr", "352x288", "4:3", "700000", "1404000", 50, "25", 3, "disable","enable", "top_field_first", "enable", 
     "mp3", "80000", 100, "stereo", 2, 44100 },
    
    /*input file: mpeg, output file: mp4 h.264 high*/
    {"mp4_h264_high.xml", INPUT_VIDEO_MPEG2, "file", "auto", 0, 
     "mp4_h264_high.mp4", "mp4", 
     "h264", "high", "30", "cbr", "352x288", "4:3", "700000", "1404000", 50, "25", 3, "disable","enable", "top_field_first", "enable", 
     "mp3", "80000", 100, "stereo", 2, 44100 },
    
    /*test dvd file input*/
    /*{"dvd_file_3gp.xml", "Elephants.Dream/VIDEO_TS/VTS_01_0.VOB", "file", "auto", 0, 
     "vts_1.3gp", "3gp", 
     "h264", "baseline", "30", "cbr", "176x144", "4:3", "1404000", "1404000", 50, "25", 3, "disable","enable", "top_field_first", "enable", 
     "aac_lc", "80000", 100, "mono", 1, 48000 },
    
    {"dvd_image_3gp.xml", "Elephants.Dream/", "dvd", "dvd", 1, 
     "elephands_dream.3gp", "3gp", 
     "h264", "baseline", "30", "cbr", "176x144", "4:3", "1404000", "1404000", 50, "25", 3, "disable","enable", "top_field_first", "enable", 
     "aac_lc", "80000", 100, "mono", 1, 48000 },*/
    
    {NULL}
};

static const char *default_conf = "\
<?xml version=\"1.0\" encoding=\"UTF-8\"?>\
<!DOCTYPE otranscode SYSTEM \"/offline/request.dtd\">\
<otranscode version=\"1.0\" description=\"YUVAD offline transcode configuration file\">\
</otranscode>";

/* global xml parse context */
static xmlParserCtxtPtr parse_ctxt = NULL;

int init_parse_ctx(xmlDocPtr *doc)
{
    *doc = NULL;
    
    if(parse_ctxt == NULL) {
        parse_ctxt = xmlNewParserCtxt();
        if(parse_ctxt == NULL) {
            err_msg("Failed to allocate parser context.\n");
            return -1;
        }
    }
    
    *doc = xmlCtxtReadMemory(parse_ctxt, default_conf, strlen(default_conf),
                             "otranscode.xml", NULL,
                             XML_PARSE_DTDVALID | XML_PARSE_DTDATTR | XML_PARSE_DTDLOAD |
                             XML_PARSE_NOBLANKS | XML_PARSE_NOERROR | XML_PARSE_NOWARNING);
    if(*doc == NULL) {
        dbg_msg("Failed to get parse doc.\n");
        return -1;
    }
    return 0;
}

int open_xml_file(xmlDocPtr *parse_doc)
{
    int ret;
    xmlNodePtr root_node = NULL;

    /*get doc*/
    ret = init_parse_ctx(parse_doc);
    if(ret < 0) {
         return -1;
    }

    root_node = xmlDocGetRootElement(*parse_doc);
    if(root_node == NULL) {
        dbg_msg("%s: has root node.\n", __FUNCTION__);
        return -1;
    }

    return 0;
}

int close_xml_file(char *filename, xmlDocPtr *parse_doc)
{
    int ret;
    
    /* delete the file */
    unlink(filename);

    /*write xml tree in buf into file*/
    ret = xmlSaveFormatFileEnc(filename, *parse_doc, "UTF-8", 1);
    if(ret == -1) {
        err_msg("Failed to save the task list.\n");
        return -1;
    }
    
    /* free the xml doc */
    xmlFreeDoc(*parse_doc);

    return 0;
}

int write_input_node(xmlDocPtr *parse_doc, xmlNodePtr req_node, request_node *request)
{
    xmlNodePtr input_node;
    xmlNodePtr new_node;
    char val_buf[256];

    input_node = xmlNewChild(req_node, NULL, BAD_CAST "input", NULL);

    //sprintf(val_buf, "%s/%s", INPUT_PATH, request->input_file_name);
    sprintf(val_buf, "%s", request->input_file_name);
    new_node = xmlNewChild(input_node, NULL, BAD_CAST "i_path", BAD_CAST val_buf);
    sprintf(val_buf, "%s", request->input_fmt);
    new_node = xmlNewChild(input_node, NULL, BAD_CAST "i_file_fmt", BAD_CAST val_buf);
    sprintf(val_buf, "%s", request->input_type);
    new_node = xmlNewChild(input_node, NULL, BAD_CAST "i_type", BAD_CAST val_buf);

    return 0;
}

int write_output_system_parameters(xmlDocPtr *parse_doc, xmlNodePtr output_node, request_node *request)
{
    xmlNodePtr new_node;
    char val_buf[256];
    
    sprintf(val_buf, "%s", request->output_fmt);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "file_format", BAD_CAST val_buf);

    //sprintf(val_buf, "%d", output->file_size);
    //new_node = xmlNewChild(output_node, NULL, BAD_CAST "file_size", BAD_CAST val_buf);
    
    //sprintf(val_buf, "%d", output->v_duration);
    //new_node = xmlNewChild(output_node, NULL, BAD_CAST "video_duration", BAD_CAST val_buf);

    return 0;
}

int write_output_video_parameters(xmlDocPtr *parse_doc, xmlNodePtr output_node, request_node *output)
{
    xmlNodePtr new_node;
    char val_buf[256];

    sprintf(val_buf, "%s", output->v_type);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "v_type", BAD_CAST val_buf);
    
    sprintf(val_buf, "%s", output->v_profile);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "profile", BAD_CAST val_buf);
    
    sprintf(val_buf, "%s", output->v_level);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "level", BAD_CAST val_buf);
    
    sprintf(val_buf, "%s", output->rc_mode);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "rc_method", BAD_CAST val_buf);
    
    sprintf(val_buf, "%s", output->output_size);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "output_size", BAD_CAST val_buf);
    
    sprintf(val_buf, "%s", output->aspect);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "aspect", BAD_CAST val_buf);
    
    sprintf(val_buf, "%s", output->bitrate);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "v_bitrate", BAD_CAST val_buf);
    
    sprintf(val_buf, "%s", output->max_bitrate);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "max_v_bitrate", BAD_CAST val_buf);
    
    sprintf(val_buf, "%d", output->iframe_interval);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "iframe_interval", BAD_CAST val_buf);
    
    sprintf(val_buf, "%s", output->fps);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "fps", BAD_CAST val_buf);
    
    sprintf(val_buf, "%d", output->bframes);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "bframes", BAD_CAST val_buf);
    
    sprintf(val_buf, "%s", output->deinterlace);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "deinterlace", BAD_CAST val_buf);
    
    sprintf(val_buf, "%s", output->interlaced);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "interlaced", BAD_CAST val_buf);
    
    sprintf(val_buf, "%s", output->field_order);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "field_order", BAD_CAST val_buf);
    
    sprintf(val_buf, "%s", output->scenecut);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "scenecut_detect", BAD_CAST val_buf);

    return 0;
}

int write_output_audio_parameters(xmlDocPtr *parse_doc, xmlNodePtr output_node, request_node *output)
{
    xmlNodePtr new_node;
    char val_buf[256];
    
    sprintf(val_buf, "%s", output->a_type);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "a_type", BAD_CAST val_buf);
    
    sprintf(val_buf, "%s", output->a_bitrate);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "a_bitrate", BAD_CAST val_buf);
    
    sprintf(val_buf, "%d", output->volume);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "volume", BAD_CAST val_buf);
    
    sprintf(val_buf, "%s", output->channel_mode);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "channel_mode", BAD_CAST val_buf);
    
    sprintf(val_buf, "%d", output->channels);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "channels", BAD_CAST val_buf);
    
    sprintf(val_buf, "%d", output->sample_rate);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "sample_rate", BAD_CAST val_buf);

    return 0;
}

int write_output_node(xmlDocPtr *parse_doc, xmlNodePtr req_node, request_node *request)
{
    xmlNodePtr output_node;
    xmlNodePtr new_node;
    char val_buf[256];

    /* add the output node */
    output_node = xmlNewChild(req_node, NULL, BAD_CAST "output", NULL);
    
    /* output filename */
    //sprintf(val_buf, "%s/%s", OUTPUT_PATH, request->output_file_name);
    sprintf(val_buf, "%s", request->output_file_name);
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "o_path", BAD_CAST val_buf);
    
    /* system parameters */
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "system_params", NULL);
    write_output_system_parameters(parse_doc, new_node, request);

    /* video parameters */
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "video_params", NULL);
    write_output_video_parameters(parse_doc, new_node, request);
    
    /* audio parameters */
    new_node = xmlNewChild(output_node, NULL, BAD_CAST "audio_params", NULL);
    write_output_audio_parameters(parse_doc, new_node, request);

    return 0;
}

int write_xml_file(xmlDocPtr *parse_doc, request_node *request)
{
    xmlNodePtr root_node = NULL;
    xmlNodePtr req_node;

    root_node = xmlDocGetRootElement(*parse_doc);
    if(root_node == NULL)
        return -1;
    //dbg_msg("root name: %s\n",root_node->name);
    
    /*create request node in xml tree*/
    req_node = xmlNewChild(root_node, NULL, BAD_CAST "request", NULL);
    
    write_input_node(parse_doc, req_node, request);
    
    write_output_node(parse_doc, req_node, request);

    return 0;
}


int main()
{
    xmlDocPtr parse_doc;
    request_node new_request;
    request_node *ptr;
    char filename[256];
    char output_file_name[256];
    int i;
    int flag;
    
    LIBXML_TEST_VERSION;

    for(i=0; i<INPUT_VIDEO_NUM; i++) {
        ptr = test_case;
        
        memset(output_file_name, 0, sizeof(output_file_name));
        
        while(ptr->filename) {
            memset((char *)&new_request, 0, sizeof(request_node));
            new_request = *ptr;
            new_request.filename = strdup(ptr->filename);
            flag = 0;
            
            switch(i) {
                case 0:/*INPUT_VIDEO_DVD_FILE*/
                    sprintf(filename, "%s/vob_%s", XML_PATH, new_request.filename);
                    
                    memset(new_request.input_file_name, 0, sizeof(new_request.input_file_name));
                    sprintf(new_request.input_file_name, "%s/%s", INPUT_PATH, INPUT_VIDEO_DVD_FILE);
                    
                    sprintf(output_file_name, "vob_%s", new_request.output_file_name);
                    memset(new_request.output_file_name, 0, sizeof(new_request.output_file_name));
                    sprintf(new_request.output_file_name, "%s/%s", OUTPUT_PATH, output_file_name);
                    
                    flag = 1;
                    break;
                case 1:/*INPUT_VIDEO_MPEG2*/
                    sprintf(filename, "%s/mpeg_%s", XML_PATH, new_request.filename);
                    
                    memset(new_request.input_file_name, 0, sizeof(new_request.input_file_name));
                    sprintf(new_request.input_file_name, "%s/%s", INPUT_PATH, INPUT_VIDEO_MPEG2);
                    
                    sprintf(output_file_name, "mpeg_%s", new_request.output_file_name);
                    memset(new_request.output_file_name, 0, sizeof(new_request.output_file_name));
                    sprintf(new_request.output_file_name, "%s/%s", OUTPUT_PATH, output_file_name);
                    
                    flag = 1;
                    break;
                case 2:/*INPUT_VIDEO_MP4*/
                    sprintf(filename, "%s/mp4_%s", XML_PATH, new_request.filename);
                    
                    memset(new_request.input_file_name, 0, sizeof(new_request.input_file_name));
                    sprintf(new_request.input_file_name, "%s/%s", INPUT_PATH, INPUT_VIDEO_MP4);
                    
                    sprintf(output_file_name, "mp4_%s", new_request.output_file_name);
                    memset(new_request.output_file_name, 0, sizeof(new_request.output_file_name));
                    sprintf(new_request.output_file_name, "%s/%s", OUTPUT_PATH, output_file_name);
                    
                    flag = 1;
                    break;

                case 3:/*INPUT_VIDEO_DVD_IMAGE*/
                    sprintf(filename, "%s/dvdimage_%s", XML_PATH, new_request.filename);
                    
                    memset(new_request.input_file_name, 0, sizeof(new_request.input_file_name));
                    sprintf(new_request.input_file_name, "%s/%s", INPUT_PATH, INPUT_VIDEO_DVD_IMAGE);
                    
                    sprintf(output_file_name, "dvdimage_%s", new_request.output_file_name);
                    memset(new_request.output_file_name, 0, sizeof(new_request.output_file_name));
                    sprintf(new_request.output_file_name, "%s/%s", OUTPUT_PATH, output_file_name);
                  
                    memset(new_request.input_type, 0, sizeof(new_request.input_type));
                    strcpy(new_request.input_type, "dvd");
                    
                    memset(new_request.input_fmt, 0, sizeof(new_request.input_fmt));
                    strcpy(new_request.input_fmt, "dvd");

                    new_request.dvd_title = 1;

                    flag = 1;
                    break;
            }
            
            if(flag) {
                open_xml_file(&parse_doc);
                write_xml_file(&parse_doc, &new_request);
                close_xml_file( filename, &parse_doc);
            }

            if(new_request.filename)
                free(new_request.filename);
            
            ptr += 1;
        }
    }

    return 0;
}
