/*
*   one fork example
*/
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>
#include <stdlib.h>

#include "debug.h"

#define PATH_FTP    "/offline"

struct ftp_argument{
    char mode[32]; /*get or put*/
    char ftpaddr[256];  
    char username[32];
    char password[32];
    char localfile[256];
    char remotefile[256];
};

static struct ftp_argument ftp_case[]=
{
    { "get", "192.168.64.166", "offline", "yuvad", "/offline/media/Media-Library/upload/yxliu/video.vob", "VTS_01_1.VOB"},
};

int start_process(char *process_cmd)
{
    pid_t pid;
    int ret;
    int status;
   
    pid = fork();
    if(pid == -1) {
        printf("fork child process failed\n");
        return -1;
    }

    if(pid == 0 ) { /*child process*/
        dbg_msg("\nchild Waiting ftp download video, process id = %d exit.\n", pid);
        dbg_msg("\nchild cmd: %s\n", process_cmd);
        /*sprintf(cmd, "%s/offline_ftp.sh get 192.168.64.166 offline yuvad /offline/media/Media-Library/upload/yxliu/video.vob VTS_01_1.VOB", PATH_FTP);*/
        ret = execl(process_cmd, "offline_ftp.sh", ftp_case[0].mode, ftp_case[0].ftpaddr, ftp_case[0].username,
                                                   ftp_case[0].password, ftp_case[0].localfile, ftp_case[0].remotefile, 
                                                   (char *) 0);
        //system(process_cmd);
        
        return ret;
    }
    
    /*parent process*/
    dbg_msg("\nparent Waiting ftp download video, process id = %d exit.\n", pid);
    do{ 
        dbg_msg("\n*******************************\n");
        
        ret = waitpid(pid, &status, 0);
        if(ret == -1) {
            err_msg("Waitpid %d failed, errno = %d\n", pid, errno);
            break;
        }
        if(WIFEXITED(status)) {
            int retcode = WEXITSTATUS(status);
            dbg_msg("Child process %d exited normally, exit code = %d\n", pid, retcode);
        } 
        else if (WIFSIGNALED(status)) {
            int signo = WTERMSIG(status);
            dbg_msg("Child process %d killed by signal %d\n", pid, signo);
        }
        else if (WIFSTOPPED(status)) {
            dbg_msg("Child process %d killed by signal %d\n", pid, WSTOPSIG(status));
        }
        else {
            dbg_msg("Child process %d killed\n", pid);
        }
    }while(!WIFEXITED(status) && !WIFSIGNALED(status));
     
    return 0;
}

int main()
{
    char cmd[256]; 
    
    sprintf(cmd, "%s/offline_ftp.sh", PATH_FTP);
    start_process(cmd);
    
    return 0;
}
