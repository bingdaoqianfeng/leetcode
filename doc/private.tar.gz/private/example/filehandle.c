/*
 *example for formate create file
 */
#include <stdio.h>


int createfile(char *filename)
{
    FILE *fd;
    
    printf("filename: %s\n", filename);

    fd = fopen(filename, "w+");

    fprintf(fd,"video standard%d=NTSC\n",1);
    fprintf(fd,"cable standard%d=YES\n",2);

    fclose(fd);
    return 0;
}

int main()
{
    createfile("./text.conf");
    
    return 0;
}
