#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

static void term_exit(void)
{
    printf("%s\n", __FUNCTION__);
}

/*volatile avoid read value from register, should read value from address of variable */
static volatile sig_atomic_t received_sigterm = 0;

/*
* will be called when receive SIGINT or SIGTERM
*/
static void sigterm_handler(int sig)
{
    received_sigterm = sig;
    
    printf("%s: %d\n", __FUNCTION__, sig);
    
    term_exit();
}

static void term_init(void)
{
    sigset_t b_set;
    struct sigaction sig_act;
    
    sigemptyset(&b_set);
    sigaddset(&b_set, SIGINT);
    sigaddset(&b_set, SIGTERM);
    
    pthread_sigmask(SIG_UNBLOCK, &b_set, NULL);
    
    memset(&sig_act, 0, sizeof(sig_act));
    sig_act.sa_handler = sigterm_handler;
    sigaction(SIGINT , &sig_act, NULL); /* Interrupt (ANSI).  */
    sigaction(SIGTERM, &sig_act, NULL); /* Termination (ANSI).  */
    
    /* register a function to be called at normal program termination */
    atexit(term_exit);
}

void cleanupHandler(void *parm) {   
    printf("Inside cancellation cleanup handler\n");   
}

void *threadfunc(void *parm)   
{   
    unsigned int  i=0;   
    int           rc=0, oldState=0;   
    
    printf("Entered secondary thread\n");   
    pthread_cleanup_push(cleanupHandler, NULL);   
    rc = pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, &oldState);   
    
    /* Allow cancel to be pending on this thread */  
    sleep(2);   
    while (1) {   
        printf("Secondary thread is now looping\n");   
        pthread_testcancel();   
        ++i;   
        sleep(1);   
        /* pthread_testcancel() has no effect until cancelability is enabled.*/  
        /* At that time, a call to pthread_testcancel() should result in the */  
        /* pending cancel being acted upon                                   */  
        if (i == 3) {   
            printf("Cancel state set to ENABLE\n");   
            rc = pthread_setcancelstate(PTHREAD_CANCEL_ENABLE,&oldState);   
            /* Now, cancellation points will allow pending cancels  
            to get through to this thread */ 
            
            /*set PTHREAD_CANCEL_DEFERRED, the thread will exit at next cancel point.*/
            //pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, NULL);
            /*set PTHREAD_CANCEL_ASYNCHRONOUS, the thread will exit at once if there is some held pending cancel signal.*/
            //pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);
        } 
    } /* infinite */  
    
    pthread_cleanup_pop(0);   
    return NULL;   
}   

int create_pthread()
{
    pthread_t             thread;   
    int                   rc=0;   
    void                 *status=NULL;   
    
    /* Create a thread using default attributes */  
    printf("Create thread using the NULL attributes\n");   
    rc = pthread_create(&thread, NULL, threadfunc, NULL);   
    sleep(1);  

    printf("Cancel the thread\n");   
    rc = pthread_cancel(thread);   
    
    rc = pthread_join(thread, &status);   
    if (status != PTHREAD_CANCELED) {   
        printf("Thread returned unexpected result!\n");   
        return -1;   
    }
    printf("Main completed\n");   
    return 0;
}

int main(int argc, char **argv)
{
    term_init();
    
    create_pthread();

    return 1;
}

