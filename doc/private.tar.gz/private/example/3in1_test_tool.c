#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "my_global.h"
#include "m_string.h"
#include "mysql.h"
#define INCLUDE_MYSQL_LIST_DEFINE

#define SQL_STR_LENGTH  3000

typedef struct
{
    char job_name[256];
    int duration;
    char *content;
    int char_count;
    char graphic_name[256];
    char graphic_path[256];
    int graphic_height;
    int graphic_width;
    char graphic_attribute[256];
}job_t;

typedef struct 
{
    int job_id;
    int start_x;
    int start_y;
    int end_x;
    int end_y;
    char font[256];
    int font_size;
    int font_bold;
    int font_italic;
    char font_path[256];
    int outside_border;
    unsigned int outside_color;
    unsigned int font_color;
    unsigned int bg_color;
    int bg_transparency;
}job_text_t;

typedef struct
{
    int job_id;
    int start_x;
    int start_y;
    int scale_width;
    int scale_height;
    int transparency;
}job_graphic_t;


int get_id(char *sql_str);
int insert_job_map_case(int job_id, int channel_id);

static int db_open( MYSQL **conn )
{
    int i = 0;
    
    /* connect to mysql for get data from database*/
    *conn = mysql_init(NULL);
    while(mysql_real_connect(*conn, "127.0.0.1", "root", "yuvadbj", "overlay", 0, NULL,
                            CLIENT_INTERACTIVE) == NULL) {
        printf("can not open mysql: %d\n", i);
        if(++i == 3)
            return -1;
        sleep(3);
    }
    
    mysql_query(*conn, "SET NAMES 'utf8'");/* use utf8 as character set */
    
    return 0;
}

static int db_close( MYSQL **conn )
{
    mysql_close(*conn);
    return 0;
}

/* delete all item of OL_FP_Database */
int delete_fp_from_db()
{
    MYSQL *conn;
    char sql_str[SQL_STR_LENGTH];
    
    db_open(&conn);
    
    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
            "DELETE FROM OL_FP_Database ");
    
    //printf("sql_str: %s\n",sql_str);
    if(mysql_query(conn, sql_str) != 0) {
        printf("delete fp failed: %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    
    db_close(&conn);
    return 0;
}

int get_job_id(char *job_name)
{
    char sql_str[SQL_STR_LENGTH];
    int job_id;
    
    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
            "SELECT  JOB_ID FROM OL_FP_Job WHERE JOB_NAME=\"%s\"", job_name);
    job_id = get_id(sql_str);

    return job_id;
}

int get_channel_id(char *channel_name)
{
    char sql_str[SQL_STR_LENGTH];
    int channel_id;
    
    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
            "SELECT  STATION_ID FROM OL_Channel WHERE STATION_NAME=\"%s\"", channel_name);
    channel_id = get_id(sql_str);

    return channel_id;
}

int get_job_map_id(int job_id, int channel_id)
{
    char sql_str[SQL_STR_LENGTH];
    int job_map_id = -1;
    
    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
            "SELECT  JOBMAP_ID FROM OL_FP_JobMap WHERE JOB_ID=%d AND STATION_ID=%d", job_id, channel_id);
    job_map_id = get_id(sql_str);
    
    return job_map_id;
}

int delete_db(char *sql_str)
{
    MYSQL *conn;
    
    db_open(&conn);
    
    if(mysql_query(conn, sql_str) != 0) {
        printf("delete error: %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    
    db_close(&conn);
    return 0;
}

int insert_db(char *sql_str)
{
    MYSQL *conn;
    
    db_open(&conn);

    //printf("sql_str: %s\n",sql_str);
    if(mysql_query(conn, sql_str) != 0) {
        printf("insert \"%s\" error: %s\n", sql_str, mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    
    db_close(&conn);
            
    return 0;
}

int get_id(char *sql_str)
{
    int id =-1;
    MYSQL_RES *result;  //result of the SELECT query
    MYSQL_ROW row;      //a record of the SELECT query
    MYSQL *conn;
    
    db_open(&conn);
    
    if(mysql_query(conn, sql_str) != 0) {
        printf(" %s\n", mysql_error(conn));
        db_close(&conn);
        return id;
    }
    
    result = mysql_store_result(conn);
    if(result == NULL) {
        printf("failed: %s\n", mysql_error(conn));
        db_close(&conn);
        return id;
    }
    
    if( (row = mysql_fetch_row(result)) != NULL) {
        id = atoi(row[0]);
    }
    //release memory    
    
    mysql_free_result(result);
    db_close(&conn);
    
    return id;
}

/*
*   flag: 1, the job already exists
*   flag: 0, insert the new job
*/
int create_job_case( job_t *new_job, int *flag ) 
{
    char sql_str[SQL_STR_LENGTH];
    int job_id;
    
    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
            "INSERT INTO OL_FP_Job ( "
            "JOB_NAME, DURATION, CONTENT, CHAR_COUNT, "
            "GRAPHIC_NAME, GRAPHIC_PATH, GRAPHIC_HEIGHT, GRAPHIC_WIDTH, GRAPHIC_ATTRIBUTE ) "
            "VALUES ( "
            "\"%s\", %d, \"%s\", %d, "
            "\"%s\", \"%s\", %d, %d,\"%s\" )",
            new_job->job_name, new_job->duration, new_job->content,new_job->char_count, 
            new_job->graphic_name, new_job->graphic_path, new_job->graphic_height, 
            new_job->graphic_width, new_job->graphic_attribute);
    //printf("%s: %s\n", __FUNCTION__, sql_str);

    if(insert_db(sql_str) == -1) {
        /*the new job already exists*/
        *flag = 1;
    }
    else
        *flag = 0;
    
    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
        "SELECT  JOB_ID FROM OL_FP_Job WHERE JOB_NAME=\"%s\"", new_job->job_name);
    job_id = get_id(sql_str);
    //printf("job_id: %d\n", job_id);

    return job_id;
}

int create_job_text_profile(job_text_t *new_job_text)
{
    char sql_str[SQL_STR_LENGTH];
    
    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
            "INSERT INTO OL_FP_JobText ( "
            "JOB_ID, TEXT_START_X, TEXT_START_Y, END_X, END_Y, "
            "FONT, FONT_SIZE, FONT_BOLD, FONT_ITALIC, FONT_PATH, "
            "OUTSIDE_BORDER, OUTSIDE_COLOR, FONT_COLOR, BG_COLOR, BG_TRANSPARENCY ) "
            "VALUES ( "
            "%d, %d, %d, %d, %d, "
            "\"%s\", %d, %d, %d, \"%s\", "
            "%d, %d, %d, %d, %d )",
            new_job_text->job_id, new_job_text->start_x, new_job_text->start_y, new_job_text->end_x, new_job_text->end_y,
            new_job_text->font, new_job_text->font_size, new_job_text->font_bold, new_job_text->font_italic, new_job_text->font_path,
            new_job_text->outside_border, new_job_text->outside_color, new_job_text->font_color, 
            new_job_text->bg_color, new_job_text->bg_transparency);
    //printf("%s: %s\n", __FUNCTION__, sql_str);
    
    insert_db(sql_str);
    
    return 0;
}

int create_job_graphic_profile(job_graphic_t *new_job_graphic)
{
    char sql_str[SQL_STR_LENGTH];
    
    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
            "INSERT INTO OL_FP_JobGraphic ( "
            "JOB_ID, GRAPHIC_START_X, GRAPHIC_START_Y, SCALEWIDTH, SCALEHEIGHT,  "
            "TRANSPARENCY ) "
            "VALUES ( "
            "%d, %d, %d, %d, %d, "
            "%d )",
            new_job_graphic->job_id, new_job_graphic->start_x, new_job_graphic->start_y, 
            new_job_graphic->scale_width, new_job_graphic->scale_height,
            new_job_graphic->transparency);
    //printf("%s: %s\n", __FUNCTION__, sql_str);
    
    insert_db(sql_str);
    
    return 0;
}

int create_job_map_case(int jobid)
{
    char sql_str[SQL_STR_LENGTH];
    time_t timep;
    struct tm *p;
    char day[32];
    int jobmapid;
    
    time(&timep);
    p = localtime(&timep);
    snprintf(day, sizeof(day),"%d-%d-%d",(1900+p->tm_year),(1+p->tm_mon), p->tm_mday);

    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
            "INSERT INTO OL_FP_JobMap ( "
            "JOB_ID, PLAY_DATE )"
            "VALUES ( "
            "%d, \"%s\" )",
            jobid, day); 
    //printf("%s: %s\n", __FUNCTION__, sql_str);

    insert_db(sql_str);
    
    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
            "SELECT  JOBMAP_ID FROM OL_FP_JobMap WHERE JOB_ID=%d", jobid);
    jobmapid = get_id(sql_str);
    printf("jobmapid: %d\n", jobmapid);

    return jobmapid;
}

int create_job_map_item(int job_map_id, char *fp_id, char *fp_name)
{
    char sql_str[SQL_STR_LENGTH];
    
    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
            "INSERT INTO OL_FP_JobMapItem ( "
            "JOBMAP_ID, FP_ID, FP_NAME )"
            "VALUES ( "
            "%d, \"%s\", \"%s\" )",
            job_map_id, fp_id, fp_name); 
    //printf("%s: %s\n", __FUNCTION__, sql_str);

    insert_db(sql_str);
    
    return 0;
}

int copy_job(int old_job_id, job_t *new_job, char *job_content)
{
    MYSQL *conn;
    MYSQL_RES *result;  //result of the SELECT query
    MYSQL_ROW row;      //a record of the SELECT query
    char sql_str[SQL_STR_LENGTH];
    int ret_num;
    int i = 0;

    db_open(&conn);
    
    snprintf(sql_str, sizeof(sql_str),
        "SELECT  "
            "DURATION, GRAPHIC_NAME, GRAPHIC_PATH, GRAPHIC_HEIGHT, GRAPHIC_WIDTH, GRAPHIC_ATTRIBUTE "
        "FROM "
            "OL_FP_Job "
        "WHERE "
            "JOB_ID = %d ",
            old_job_id);
    //printf("%s: %s  \n",__FUNCTION__, sql_str);
    if(mysql_query(conn, sql_str) != 0) {
        printf("search ol schedult failed: %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    result = mysql_store_result(conn);
    if(result == NULL) {
        printf("search text schedult failed: %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    ret_num = (int)mysql_num_rows(result);
    //printf("%d records found \n",ret_num);
    while( (row = mysql_fetch_row(result)) != NULL) {
        i = 0;
        new_job->duration = atoi(row[i++]);
        sprintf(new_job->graphic_name ,"%s",row[i++]);
        sprintf(new_job->graphic_path ,"%s",row[i++]);
        new_job->graphic_height = atoi(row[i++]);
        new_job->graphic_width = atoi(row[i++]);
        sprintf(new_job->graphic_attribute ,"%s",row[i++]);
    }
    new_job->content = strdup(job_content);
    new_job->char_count = strlen(job_content);
    snprintf(new_job->job_name, 256, "%s", job_content);
    mysql_free_result(result);
    db_close(&conn);
    
    return 0;
}

int copy_job_text(int old_job_id, int new_job_id, job_text_t *new_job_text)
{
    MYSQL *conn;
    MYSQL_RES *result;  //result of the SELECT query
    MYSQL_ROW row;      //a record of the SELECT query
    char sql_str[SQL_STR_LENGTH];
    int ret_num;
    int i = 0;

    db_open(&conn);
    
    snprintf(sql_str, sizeof(sql_str),
        "SELECT  "
            "TEXT_START_X, TEXT_START_Y, END_X, END_Y, "
            "FONT, FONT_SIZE, FONT_BOLD, FONT_ITALIC, FONT_PATH, "
            "OUTSIDE_BORDER, OUTSIDE_COLOR, FONT_COLOR, BG_COLOR, BG_TRANSPARENCY "
        "FROM "
            "OL_FP_JobText "
        "WHERE "
            "JOB_ID = %d ",
            old_job_id);
    //printf("%s: %s  \n",__FUNCTION__, sql_str);
    if(mysql_query(conn, sql_str) != 0) {
        printf("search ol schedult failed: %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    result = mysql_store_result(conn);
    if(result == NULL) {
        printf("search text schedult failed: %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    ret_num = (int)mysql_num_rows(result);
    //printf("%d records found \n",ret_num);
    if(ret_num == 0) {
        mysql_free_result(result);
        db_close(&conn);
        return -1;
    }
    while( (row = mysql_fetch_row(result)) != NULL) {
        i = 0;
        new_job_text->start_x = atoi(row[i++]);
        new_job_text->start_y = atoi(row[i++]);
        new_job_text->end_x = atoi(row[i++]);
        new_job_text->end_y = atoi(row[i++]);
        sprintf(new_job_text->font ,"%s",row[i++]);
        new_job_text->font_size = atoi(row[i++]);
        new_job_text->font_bold = atoi(row[i++]);
        new_job_text->font_italic = atoi(row[i++]);
        sprintf(new_job_text->font_path ,"%s",row[i++]);
        
        new_job_text->outside_border = atoi(row[i++]);
        new_job_text->outside_color = atoi(row[i++]);
        new_job_text->font_color = atoi(row[i++]);
        new_job_text->bg_color = atoi(row[i++]);
        new_job_text->bg_transparency = atoi(row[i++]);
    }
    new_job_text->job_id = new_job_id;
    
    mysql_free_result(result);
    db_close(&conn);
    
    return 0;
}

int copy_job_graphic(int old_job_id, int new_job_id, job_graphic_t *new_job_graphic)
{
    MYSQL *conn;
    MYSQL_RES *result;  //result of the SELECT query
    MYSQL_ROW row;      //a record of the SELECT query
    char sql_str[SQL_STR_LENGTH];
    int ret_num;
    int i = 0;

    db_open(&conn);
    
    snprintf(sql_str, sizeof(sql_str),
        "SELECT  "
            "GRAPHIC_START_X, GRAPHIC_START_Y, SCALEHEIGHT, SCALEWIDTH, TRANSPARENCY "
        "FROM "
            "OL_FP_JobGraphic "
        "WHERE "
            "JOB_ID = %d ",
            old_job_id);
    //printf("%s: %s  \n",__FUNCTION__, sql_str);
    if(mysql_query(conn, sql_str) != 0) {
        printf("search ol schedult failed: %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    result = mysql_store_result(conn);
    if(result == NULL) {
        printf("search text schedult failed: %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    ret_num = (int)mysql_num_rows(result);
    //printf("%d records found \n",ret_num);
    if(ret_num == 0) {
        mysql_free_result(result);
        db_close(&conn);
        return -1;
    }
    while( (row = mysql_fetch_row(result)) != NULL) {
        i = 0;
        new_job_graphic->start_x = atoi(row[i++]);
        new_job_graphic->start_y = atoi(row[i++]);
        new_job_graphic->scale_height = atoi(row[i++]);
        new_job_graphic->scale_width = atoi(row[i++]);
        new_job_graphic->transparency = atoi(row[i++]);
    }
    new_job_graphic->job_id = new_job_id;
    
    mysql_free_result(result);
    db_close(&conn);
    
    return 0;
}

int create_new_job(int old_job_id, char *job_content)
{
    time_t timep;
    struct tm *p;
    char day[32];
    int new_job_id;
    int flag;

    job_t new_job;
    job_text_t new_job_text;
    job_graphic_t new_job_graphic;

    time(&timep);
    p = localtime(&timep);
    snprintf(day, sizeof(day),"%d-%d-%d",(1900+p->tm_year),(1+p->tm_mon), p->tm_mday);
    
    copy_job(old_job_id, &new_job, job_content);   
    new_job_id = create_job_case(&new_job, &flag);

    if(flag) /*the job already exists, so don't need to recreate its profile*/
        return new_job_id;

    copy_job_text(old_job_id, new_job_id, &new_job_text);
    create_job_text_profile(&new_job_text);

    copy_job_graphic(old_job_id, new_job_id, &new_job_graphic);
    create_job_graphic_profile(&new_job_graphic);

    return new_job_id;
}

int insert_all_fp_into_jobmapitem(int job_id, int channel_id)
{
    MYSQL_RES *result;  //result of the SELECT query
    MYSQL_ROW row;      //a record of the SELECT query
    MYSQL *conn;
    char sql_str[SQL_STR_LENGTH];
    int fp_num = 0;
    int job_map_id;
    int new_job_id;
    
    
    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
            "SELECT FP_ID, FP_NAME FROM OL_FP_Database WHERE STATION_ID=%d", channel_id);
    
    db_open(&conn);
    
    if(mysql_query(conn, sql_str) != 0) {
        printf(" %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    
    result = mysql_store_result(conn);
    if(result == NULL) {
        printf("failed: %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    
    fp_num = (int)mysql_num_rows(result);
    printf("fp number: %d\n",fp_num);
    if(!fp_num)
        return 0;
    
    while( (row = mysql_fetch_row(result)) != NULL) {
        /*create a new job according to fp name and specified job*/
        new_job_id = create_new_job(job_id, row[1]);
    
        job_map_id = insert_job_map_case(new_job_id, channel_id);
        //printf("%s:  job_map_id: %d\n", __FUNCTION__, job_map_id);
        if(job_map_id == -1) {
            printf("insert job map failed\n");
            continue;
        }
        
        create_job_map_item(job_map_id, row[0], row[1]);
    }
    
    mysql_free_result(result);
    db_close(&conn);
    
    return 0;
}

/*delete job map case*/
int remove_all_job_map(int job_id)
{
    MYSQL *conn;
    MYSQL_RES *result;  //result of the SELECT query
    MYSQL_ROW row;      //a record of the SELECT query
    char sql_str[SQL_STR_LENGTH];
    int ret_num;
    int i = 0;
    int job_map_id;

    db_open(&conn);
    
    snprintf(sql_str, sizeof(sql_str),
        "SELECT  JOBMAP_ID FROM OL_FP_JobMap WHERE JOB_ID=%d ", job_id);
    //printf("%s: %s  \n",__FUNCTION__, sql_str);
    if(mysql_query(conn, sql_str) != 0) {
        printf("search ol schedult failed: %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    result = mysql_store_result(conn);
    if(result == NULL) {
        printf("search text schedult failed: %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    ret_num = (int)mysql_num_rows(result);
    //printf("job_map number: %d\n",ret_num);
    while( (row = mysql_fetch_row(result)) != NULL) {
        i = 0;
        job_map_id = atoi(row[i++]);
        //printf("job_map_id: %d\n", job_map_id);
            
        memset(sql_str, 0, SQL_STR_LENGTH);
        snprintf(sql_str, sizeof(sql_str),
                "DELETE FROM OL_FP_JobMapItem WHERE JOBMAP_ID=%d", job_map_id);
        delete_db(sql_str);
    
    }
        
    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
            "DELETE FROM OL_FP_JobMap WHERE JOB_ID=%d", job_id);
    delete_db(sql_str);        
    
    mysql_free_result(result);
    db_close(&conn);
    
    return 0;

/*********************************************/
    
    return 0;
}

int remove_job_profile(int job_id)
{
    char sql_str[SQL_STR_LENGTH];
   
    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
            "DELETE FROM OL_FP_JobText WHERE JOB_ID=%d", job_id);
    delete_db(sql_str);
    
    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
            "DELETE FROM OL_FP_JobGraphic WHERE JOB_ID=%d", job_id);
    delete_db(sql_str);
    
    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
            "DELETE FROM OL_FP_Job WHERE JOB_ID=%d", job_id);
    delete_db(sql_str);
    
    return 0;
}

/*will remove all job except the job that job id is job_id*/
int remove_job(int job_id)
{
    MYSQL *conn;
    MYSQL_RES *result;  //result of the SELECT query
    MYSQL_ROW row;      //a record of the SELECT query
    char sql_str[SQL_STR_LENGTH];
    int ret_num;
    int i = 0;
    int remove_job_id;

    db_open(&conn);
    
    snprintf(sql_str, sizeof(sql_str),
        "SELECT  JOB_ID "
        "FROM "
            "OL_FP_Job ");
    //printf("%s: %s  \n",__FUNCTION__, sql_str);
    if(mysql_query(conn, sql_str) != 0) {
        printf("search ol schedult failed: %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    result = mysql_store_result(conn);
    if(result == NULL) {
        printf("search text schedult failed: %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    ret_num = (int)mysql_num_rows(result);
    printf("job number: %d \n",ret_num);
    while( (row = mysql_fetch_row(result)) != NULL) {
        i = 0;
        remove_job_id = atoi(row[i++]);
        remove_all_job_map(remove_job_id);
        if(job_id != remove_job_id)
            remove_job_profile(remove_job_id);
    }
    
    mysql_free_result(result);
    db_close(&conn);
    
    return 0;
}


int insert_job_map_case(int job_id, int channel_id)
{
    char sql_str[SQL_STR_LENGTH];
    time_t timep;
    struct tm *p;
    char day[32];
    int job_map_id = -1;
    
    job_map_id = get_job_map_id(job_id, channel_id);
    if(job_map_id != -1)
        return job_map_id;
    
    time(&timep);
    p = localtime(&timep);
    snprintf(day, sizeof(day),"%d-%d-%d",(1900+p->tm_year),(1+p->tm_mon), p->tm_mday);

    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
            "INSERT INTO OL_FP_JobMap ( "
            "JOB_ID, STATION_ID, PLAY_DATE )"
            "VALUES ( "
            "%d, %d, \"%s\" )",
            job_id, channel_id, day); 
    //printf("%s: %s\n", __FUNCTION__, sql_str);

    insert_db(sql_str);
    
    job_map_id = get_job_map_id(job_id, channel_id);
    
    return job_map_id;
}

static void add_one_job_for_each_fp(int job_id, int channel_id)
{
    remove_job(job_id);

    insert_all_fp_into_jobmapitem(job_id, channel_id);
    
    return;
}

static int remove_all_job_map_of_specified_channel(int channel_id)
{
    MYSQL *conn;
    MYSQL_RES *result;  //result of the SELECT query
    MYSQL_ROW row;      //a record of the SELECT query
    char sql_str[SQL_STR_LENGTH];
    int ret_num;
    int i = 0;
    int job_map_id;

    db_open(&conn);
    
    snprintf(sql_str, sizeof(sql_str),
        "SELECT  JOBMAP_ID FROM OL_FP_JobMap WHERE STATION_ID=%d ", channel_id);
    //printf("%s: %s  \n",__FUNCTION__, sql_str);
    if(mysql_query(conn, sql_str) != 0) {
        printf("search ol schedult failed: %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    result = mysql_store_result(conn);
    if(result == NULL) {
        printf("search text schedult failed: %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    ret_num = (int)mysql_num_rows(result);
    //printf("job_map number: %d\n",ret_num);
    while( (row = mysql_fetch_row(result)) != NULL) {
        i = 0;
        job_map_id = atoi(row[i++]);
        //printf("job_map_id: %d\n", job_map_id);
            
        memset(sql_str, 0, SQL_STR_LENGTH);
        snprintf(sql_str, sizeof(sql_str),
                "DELETE FROM OL_FP_JobMapItem WHERE JOBMAP_ID=%d", job_map_id);
        delete_db(sql_str);
    
    }
        
    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
            "DELETE FROM OL_FP_JobMap WHERE STATION_ID=%d", channel_id);
    delete_db(sql_str);        
    
    mysql_free_result(result);
    db_close(&conn);
    
    return 0;
}

static int add_all_fp_to_one_job(int job_id, int channel_id)
{
    MYSQL_RES *result;  //result of the SELECT query
    MYSQL_ROW row;      //a record of the SELECT query
    MYSQL *conn;
    char sql_str[SQL_STR_LENGTH];
    int fp_num = 0;
    int job_map_id;
   
    /*remove all exist job map of channel*/
    remove_all_job_map_of_specified_channel(channel_id);
        
    /*insert a new job map for the job, and get job_map_id*/    
    job_map_id = insert_job_map_case(job_id, channel_id);
    if(job_map_id == -1) {
        printf("%s: insert new job_map error\n", __FUNCTION__);
        return -1;
    }
    
    memset(sql_str, 0, SQL_STR_LENGTH);
    snprintf(sql_str, sizeof(sql_str),
            "SELECT FP_ID, FP_NAME FROM OL_FP_Database WHERE STATION_ID=%d", channel_id);
    db_open(&conn);
    
    if(mysql_query(conn, sql_str) != 0) {
        printf(" %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    
    result = mysql_store_result(conn);
    if(result == NULL) {
        printf("failed: %s\n", mysql_error(conn));
        db_close(&conn);
        return -1;
    }
    
    fp_num = (int)mysql_num_rows(result);
    printf("fp number: %d\n",fp_num);
    if(!fp_num)
        return 0;
    while( (row = mysql_fetch_row(result)) != NULL) {
        create_job_map_item(job_map_id, row[0], row[1]);
    }
    
    mysql_free_result(result);
    db_close(&conn);
    
    return 0;
}

void usage()
{
	fprintf(stdout,"create new job for each fp according to specified job\n");
	fprintf(stdout,"./importfpdb mode channel_name job_name \n\n");
	fprintf(stdout,"mode=1, will add new job for each fp, the new job profile is copy job_name's profile,\n"
                    "the new job name is the fp name. if there are some duplicate name fp, \n"
                    "will just create one job for those fp, and these fp will be mapped to the same job\n\n");
	fprintf(stdout,"mode=2, will add all fp of channle_name to the specified job(job_name) \n\n");
	fprintf(stdout,"example ./importfpdb 1 cctv1 testjob \n");
	fprintf(stdout,"example ./importfpdb 2 cctv1 testjob \n");
}


int main(int argc, char *argv[])
{
    int mode;
    char channel_name[256];
    char job_name[256];
    int job_id;
    int channel_id;
    int i = 1;
	
    if(argc != 4){
		usage();
		return 0;
	}

    mode = atoi(argv[i++]);
    printf("mode: %d\n", mode);
    strcpy(channel_name, argv[i++]);
    strcpy(job_name, argv[i++]);
    printf("channel_name: %s, job_name: %s\n", channel_name, job_name);

    job_id = get_job_id(job_name);
    printf("job_id: %d\n", job_id);
    if(job_id == -1)
        return 0;

    channel_id = get_channel_id(channel_name);
    printf("channel_id: %d\n", channel_id);
    if(channel_id == -1)
        return 0;
   
    switch(mode) {
        case 1:
            add_one_job_for_each_fp(job_id, channel_id);
            break;
        case 2:
            add_all_fp_to_one_job(job_id, channel_id);
            break;
        default:
            usage();
    }
    
    return 0;
}
