#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "yuvad_list.h"


#define MAX_LEN_EACH_LINE   500

typedef struct double_color
{
    struct list_head node;
    char lottery_ticket[256];
    int red_ball[6];
    int blue_ball;
}double_color_t;

struct list_head listhead;

static void display_list(struct list_head *head)
{
    struct list_head *pos;
    double_color_t *pos_entry;
    int i;
    int num = 0;

    if(list_empty(head))
        return;

    list_for_each(pos, head) {
        pos_entry = list_entry(pos, double_color_t, node);
            
        printf("lottety_ticket: %s\n",pos_entry->lottery_ticket);
        printf("red ball:");
        for(i=0; i<6; i++)
            printf(" %02d\t", pos_entry->red_ball[i]);
        printf("\n");
        printf("red ball: %02d\t\n", pos_entry->blue_ball);
        num++;
    }
        
    printf("num: %d\n", num);

    return;
}

static void create_double_color_ball_db(struct list_head *head, char *filename)
{
    struct list_head *pos;
    double_color_t *pos_entry;
    int num = 0;
    FILE *fd;
    
    fd = fopen(filename,"w");
    if(fd == NULL)
    {
        printf("fopen (%s) is failed \n", filename);
        return;
    }

    if(list_empty(head))
        return;

    list_for_each(pos, head) {
        pos_entry = list_entry(pos, double_color_t, node);
            
        fprintf(fd, "lottety_ticket: %s\n",pos_entry->lottery_ticket);
        fprintf(fd, "red ball: %02d-%02d-%02d-%02d-%02d-%02d\n",
                    pos_entry->red_ball[0], pos_entry->red_ball[1], pos_entry->red_ball[2],
                    pos_entry->red_ball[3], pos_entry->red_ball[4], pos_entry->red_ball[5]);
        fprintf(fd, "red ball: %02d\n", pos_entry->blue_ball);
        num++;
    }
       
    fclose(fd);
    printf("num: %d\n", num);

    return;
}

static int get_border_value(char *borderfile, char *di, char *qi, char *blueball, char *redball)
{
    FILE *fd;
    char str[MAX_LEN_EACH_LINE];
    char *retptr;
    char *offset;
    int allnum = 0;

    fd = fopen(borderfile,"r");
    if(fd == NULL)
    {
        printf("fopen (%s) is failed \n", borderfile);
        return -1;
    }

    while(1)
    {
        memset(str, 0, MAX_LEN_EACH_LINE);
        retptr = fgets(str, MAX_LEN_EACH_LINE, fd);
        if(!retptr)
            break;

        offset = index(str, '\n');
        if(offset)
            *offset = 0;
        offset = index(str, '\t');
        if(offset)
            *offset = 0;
       
        //printf("str: %s\n",str);
        switch(allnum)
        {
            case 0:
                strncpy(di, str, 2);
                strncpy(qi, str+10, 2);
                //printf("di: %s, qi: %s\n", di, qi);
                break;
            case 1:
                strncpy(redball, str, 6);
                //printf("redball: %s\n", redball);
                break;
            case 2:
                strncpy(blueball, str, 6);
                //printf("blueball: %s\n", blueball);
                break;
        }

        allnum++;
    }
    fclose(fd);
    
    return 0;
}

static int read_original_data_file(struct list_head *head, char *filename, char *borderfile)
{
    FILE *fd;
    char str[MAX_LEN_EACH_LINE];
    char *retptr;
    char *offset;
    int allnum = 0;
    double_color_t *new_double;

    char di[32];
    char qi[32];
    char blueball[32];
    char redball[32];

   
    memset(di, 0, sizeof(di));
    memset(qi, 0, sizeof(qi));
    memset(blueball, 0, sizeof(blueball));
    memset(redball, 0, sizeof(redball));
    get_border_value(borderfile, di, qi, blueball, redball);

    //struct list_head *ptr;
    //int ticketnum = 0;
    
    //printf("------------------------------------------\n");
    
    fd = fopen(filename ,"r");
    if(fd == NULL)
    {
        printf("fopen (%s) is failed \n", filename);
        return -1;
    }

    while(1)
    {
        memset(str, 0, MAX_LEN_EACH_LINE);
        retptr = fgets(str, MAX_LEN_EACH_LINE, fd);
        if(!retptr)
            break;

        offset = index(str, '\n');
        if(offset)
            *offset = 0;
        
        offset = index(str, '\r');
        if(offset)
            *offset = 0;
        
        if(!strncmp(redball, str, strlen(redball)))
            continue;
        if(!strncmp(blueball, str, strlen(blueball)))
            continue;
        if(strlen(str) == 0 || strlen(str) == 1)
            continue;

        if(!strncmp(di, str, strlen(di)))
        {/*get date*/
            char *p, *q;
            //printf("str: %s\n",str);
            new_double = malloc(sizeof(double_color_t));
            memset(new_double, 0, sizeof(double_color_t));
            
            p = str + strlen(di);
            //printf("p: %s\n",p);
            q = strstr(str, qi);
            if(q)
                *q = 0;
            strcpy(new_double->lottery_ticket, p);
            //printf("lottety_ticket: %s\n",new_double->lottery_ticket);
        }
        else if(strlen(str)>3)
        {/*redball*/   
            char *p;
            char *delim="\t ";
            int i = 0;
            
            //printf("str: %s\n", str);
            /*remove \t and space in str*/ 
            p = (char *)strtok(str,delim);
            if( p == NULL ) 
            {
                printf("error: there is no space \n");
                continue;
            }
            else
            {
                //printf("p: %s, %d\n", p, atoi(p));
                new_double->red_ball[i++] = atoi(p);
            }
            while( (p = (char *)strtok( NULL, delim)) ) 
            {
                //printf("p: %s, %d\n", p, atoi(p));
                new_double->red_ball[i++] = atoi(p);
            }
        }
        else
        {/*blue ball*/
            new_double->blue_ball = atoi(str);
            //printf("blue ball: %02d\n", new_double->blue_ball);
            list_add_tail(&(new_double->node), head);
        }

        allnum++;
    }
    fclose(fd);
    
    //printf("allnum: %d\n", allnum);

    return 0;
}

static int convert_date_to_myformate()
{
    //char filename[]="./double_color_data.txt";
    char filename[]="./double_color_ball_history_data.txt";
    char borderfile[]="./double_color_border.txt";
    char db_file[]="./double_color_ball_db.txt";

    INIT_LIST_HEAD(&listhead);
    
    read_original_data_file(&listhead, filename, borderfile);
    //display_list(&listhead);
    create_double_color_ball_db(&listhead, db_file);
    
    return 0;
}

static int read_private_db()
{
    return 0;
}

static void usage()
{
    printf("argument: <initdb|usedb>\n");
    return;
}

int main(int argc, char *argv[])
{
    int i=0;
    for(i=0; i<1; i++)
        printf("i: %d\n", i);
    return 0;

    if(argc != 2)
    {
        usage();
        return -1;
    }

    if(!strcmp(argv[1], "initdb"))
        convert_date_to_myformate();
    else if(!strcmp(argv[1], "usedb"))
        read_private_db();
    else
        usage();

    return 0;
}

