#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_FP_INDEX_LEN  128
#define FP_SCHEDULE_FILE    "./fp_schedule.txt"

typedef struct Tgalist{
	struct Tgalist *next;
	char *filename;
	int delayframenum;
    
    /*for fp overlay*/
    char id[MAX_FP_INDEX_LEN];
    char name[MAX_FP_INDEX_LEN];
    char description[MAX_FP_INDEX_LEN];
    char channel[MAX_FP_INDEX_LEN];
}Tgalist;


void inserttgalist(Tgalist *head, Tgalist *new)
{
	Tgalist *ptr;
	Tgalist *pre;

	if(head->next == NULL) {
		head->next = new;
		return;
	}

	pre = head;
	ptr = head->next;
	while(ptr != NULL) {
		if(strcmp(ptr->filename, new->filename) > 0) {/*ptr > new*/
			new->next = ptr;
			pre->next = new;
			return;
		}
		
		pre = ptr;
		ptr = ptr->next;
	}
	
	pre->next = new;

	return;
}

void freetgalist(Tgalist *head)
{
	Tgalist *ptr;
	Tgalist *pre;

	ptr = head->next;

	while(ptr != NULL) {
		pre = ptr;
		ptr = ptr->next;

		free(pre->filename);
		free(pre);
	}

	head->next = NULL;
}

void writescheduledb(Tgalist *head)
{
    FILE *fd;
	Tgalist *ptr;
	
    fd = fopen( FP_SCHEDULE_FILE, "w");
    if(!fd)
    {
        printf("open %s failed\n", FP_SCHEDULE_FILE);
        return;
    }

    ptr = head->next;
    while( ptr != NULL) {
        //printf("id: %s\n", ptr->id);
        //printf("description: %s\n", ptr->description);
        //printf("name: %s\n", ptr->name);
        
        fprintf(fd, "\"%s\" \"%s\" \"%s\" \"%s\"\n", ptr->id, ptr->description, "down", "there is no content");
        ptr = ptr->next;
	}

    fclose(fd);
    return;
}

int analysefpdb(char *strcmd, char *buf)
{
    FILE *fd;
    char *offset;
    
    fd = popen( strcmd, "r");
    if(!fd)
    {
        fprintf(stdout, "popen %s failed\n", strcmd);
        return -1;
    }
    if (!fgets(buf, MAX_FP_INDEX_LEN, fd)) 
    {
        fprintf(stdout, "can not get result by %s\n", strcmd);
        return -1;
    }
    
    offset = index(buf, '\n');
    if(offset)
        *offset = 0;

    pclose(fd);
    
    return 0;
}

void usage()
{
	fprintf(stdout,"./a.out path \n");
	fprintf(stdout,"example ./a.out /home/liuyuxin/develop \n");
}

int main(int argc, char *argv[])
{
	char *path;
	DIR *dir;
	struct dirent *dirptr;
	Tgalist head;
	Tgalist *ptr;
    int countnum;
    char str[1024];

	if(argc != 2){
		usage();
		return 0;
	}
	
	head.next = NULL;
	path = strdup(argv[1]);
	fprintf(stdout,"path: %s\n", path);

	dir =opendir(path);
	if(dir == NULL)
		return 0;

    countnum = 0; 
	while((dirptr = readdir(dir))!=NULL) {
		//if( !strncasecmp(dirptr->d_name, ".", 1) || !strncasecmp(dirptr->d_name, "..", 2) )
		if( !strcmp(dirptr->d_name, ".") || !strcmp(dirptr->d_name, "..") || !strstr(dirptr->d_name, ".fpm") )
            continue;
        
        //fprintf(stdout, "d_name: %s\n",dirptr->d_name);
		ptr = (Tgalist *)malloc(sizeof(Tgalist));
		ptr->delayframenum = 25;
		ptr->filename = strdup(dirptr->d_name);
		ptr->next = NULL;
        
        /* get id */
        memset(str, 0, 1024);
        snprintf(str, sizeof(str), " cat %s/%s | grep \"^id: \" | sed \"s/id: //\" ", path, dirptr->d_name);
        analysefpdb(str, ptr->id);
        
        /* get name */
        /*memset(str, 0, 1024);
        snprintf(str, sizeof(str), " cat %s/%s | grep \"^name: \" | sed \"s/name: //\" ", path, dirptr->d_name);
        analysefpdb(str, ptr->name);*/
        
        /* get description */
        memset(str, 0, 1024);
        snprintf(str, sizeof(str), " cat %s/%s | grep \"^description: \" | sed \"s/description: //\" ", path, dirptr->d_name);
        analysefpdb(str, ptr->description);

		inserttgalist(&head, ptr);

        countnum++;
	}
	closedir(dir);
    printf("countnum: %d\n", countnum);

    writescheduledb(&head);

    freetgalist(&head);
    return 0;
}
