const char psz_vlc_changeset[] = "2.2.1-0-ga425c42";
